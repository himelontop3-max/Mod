@echo off
setlocal
set "SCRIPT=%~dp0scripts\Restore-Windows-Desktop.ps1"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
pause
