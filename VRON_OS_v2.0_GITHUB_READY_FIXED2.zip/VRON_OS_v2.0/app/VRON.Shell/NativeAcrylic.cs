using System.Runtime.InteropServices;

namespace VRON.Shell;

internal static class NativeAcrylic
{
    private const int WCA_ACCENT_POLICY = 19;
    private const int ACCENT_ENABLE_ACRYLICBLURBEHIND = 4;

    [StructLayout(LayoutKind.Sequential)]
    private struct AccentPolicy
    {
        public int AccentState;
        public int AccentFlags;
        public int GradientColor;
        public int AnimationId;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct WindowCompositionAttributeData
    {
        public int Attribute;
        public IntPtr Data;
        public int SizeOfData;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern int SetWindowCompositionAttribute(IntPtr hwnd, ref WindowCompositionAttributeData data);

    /// <summary>Enables the Windows 10 native acrylic backdrop; no WPF software blur effect is used.</summary>
    public static void TryEnable(IntPtr hwnd, byte alpha = 218)
    {
        if (hwnd == IntPtr.Zero) return;
        // COLORREF-style BGRA: midnight blue (#071525) with a restrained translucent tint.
        int gradient = (alpha << 24) | (0x25 << 16) | (0x15 << 8) | 0x07;
        var policy = new AccentPolicy
        {
            AccentState = ACCENT_ENABLE_ACRYLICBLURBEHIND,
            AccentFlags = 2,
            GradientColor = gradient,
            AnimationId = 0
        };
        IntPtr memory = Marshal.AllocHGlobal(Marshal.SizeOf<AccentPolicy>());
        try
        {
            Marshal.StructureToPtr(policy, memory, false);
            var data = new WindowCompositionAttributeData
            {
                Attribute = WCA_ACCENT_POLICY,
                Data = memory,
                SizeOfData = Marshal.SizeOf<AccentPolicy>()
            };
            _ = SetWindowCompositionAttribute(hwnd, ref data);
        }
        catch
        {
            // The WPF window already has a solid midnight-blue fallback background.
        }
        finally
        {
            Marshal.FreeHGlobal(memory);
        }
    }
}
