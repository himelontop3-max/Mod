using System.Windows;

namespace VRON.Shell;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        var shellHost = new MainWindow();
        MainWindow = shellHost;
        try
        {
            shellHost.InitializeShell();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"VRON could not start. The original desktop visibility was restored where possible.\n\n{ex.Message}",
                "VRON startup error", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown();
        }
    }
}
