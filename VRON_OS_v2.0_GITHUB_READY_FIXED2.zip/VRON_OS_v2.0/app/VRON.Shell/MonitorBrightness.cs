using System.Runtime.InteropServices;

namespace VRON.Shell;

/// <summary>
/// Uses the Windows Monitor Configuration API (DDC/CI). This works with supported external
/// monitors and some laptop panels; unsupported displays fall back to Windows Display Settings.
/// </summary>
internal static class MonitorBrightness
{
    [StructLayout(LayoutKind.Sequential)]
    private struct RECT { public int Left, Top, Right, Bottom; }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct PHYSICAL_MONITOR
    {
        public IntPtr hPhysicalMonitor;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string szPhysicalMonitorDescription;
    }

    private delegate bool MonitorEnumProc(IntPtr hMonitor, IntPtr hdc, ref RECT rect, IntPtr data);

    [DllImport("user32.dll")]
    private static extern bool EnumDisplayMonitors(IntPtr hdc, IntPtr clip, MonitorEnumProc callback, IntPtr data);

    [DllImport("dxva2.dll", SetLastError = true)]
    private static extern bool GetNumberOfPhysicalMonitorsFromHMONITOR(IntPtr hMonitor, out uint count);

    [DllImport("dxva2.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern bool GetPhysicalMonitorsFromHMONITOR(IntPtr hMonitor, uint count, [Out] PHYSICAL_MONITOR[] monitors);

    [DllImport("dxva2.dll", SetLastError = true)]
    private static extern bool GetMonitorBrightness(IntPtr physicalMonitor, out uint minimum, out uint current, out uint maximum);

    [DllImport("dxva2.dll", SetLastError = true)]
    private static extern bool SetMonitorBrightness(IntPtr physicalMonitor, uint newBrightness);

    [DllImport("dxva2.dll", SetLastError = true)]
    private static extern bool DestroyPhysicalMonitors(uint count, [In] PHYSICAL_MONITOR[] monitors);

    public static bool TryGetPercent(out int percent)
    {
        percent = 60;
        int result = percent;
        bool found = false;
        MonitorEnumProc callback = (IntPtr monitor, IntPtr hdc, ref RECT rect, IntPtr data) =>
        {
            if (!TryUseFirstPhysicalMonitor(monitor, (handle, min, current, max) =>
                {
                    result = max <= min ? 60 : (int)Math.Round((current - min) * 100.0 / (max - min));
                    found = true;
                    return true;
                })) return true;
            return !found;
        };
        try { _ = EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, callback, IntPtr.Zero); }
        catch { return false; }
        percent = Math.Clamp(result, 0, 100);
        return found;
    }

    public static bool TrySetPercent(int percent)
    {
        percent = Math.Clamp(percent, 0, 100);
        bool changed = false;
        MonitorEnumProc callback = (IntPtr monitor, IntPtr hdc, ref RECT rect, IntPtr data) =>
        {
            if (!TryUseFirstPhysicalMonitor(monitor, (handle, min, current, max) =>
                {
                    uint value = (uint)Math.Round(min + (max - min) * (percent / 100.0));
                    changed = SetMonitorBrightness(handle, value);
                    return true;
                })) return true;
            return !changed;
        };
        try { _ = EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, callback, IntPtr.Zero); }
        catch { return false; }
        return changed;
    }

    private static bool TryUseFirstPhysicalMonitor(IntPtr hMonitor, Func<IntPtr, uint, uint, uint, bool> action)
    {
        if (!GetNumberOfPhysicalMonitorsFromHMONITOR(hMonitor, out uint count) || count == 0) return false;
        var monitors = new PHYSICAL_MONITOR[(int)count];
        if (!GetPhysicalMonitorsFromHMONITOR(hMonitor, count, monitors)) return false;
        try
        {
            foreach (PHYSICAL_MONITOR monitor in monitors)
            {
                if (GetMonitorBrightness(monitor.hPhysicalMonitor, out uint min, out uint current, out uint max))
                    return action(monitor.hPhysicalMonitor, min, current, max);
            }
            return false;
        }
        finally
        {
            _ = DestroyPhysicalMonitors(count, monitors);
        }
    }
}
