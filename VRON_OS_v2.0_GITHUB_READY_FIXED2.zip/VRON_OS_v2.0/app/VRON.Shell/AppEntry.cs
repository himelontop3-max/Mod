namespace VRON.Shell;

public sealed class AppEntry
{
    public string Name { get; set; } = string.Empty;
    public string Glyph { get; set; } = "\uE8A5";
    public string Category { get; set; } = "Apps";
    public string Target { get; set; } = string.Empty;
    public string Arguments { get; set; } = string.Empty;
    public bool Pinned { get; set; }
    public bool Custom { get; set; }

    public AppEntry() { }

    public AppEntry(string name, string glyph, string category, string target,
        string arguments = "", bool pinned = false, bool custom = false)
    {
        Name = name;
        Glyph = glyph;
        Category = category;
        Target = target;
        Arguments = arguments;
        Pinned = pinned;
        Custom = custom;
    }
}

public sealed class VronSettings
{
    public List<string> PinnedApps { get; set; } = new() { "Inventory", "Notes", "CMD", "Panel" };
    public List<string> PinnedAppTargets { get; set; } = new();
    public List<string> HiddenBuiltInApps { get; set; } = new();
    public Dictionary<string, string> RenamedApps { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public List<AppEntry> CustomApps { get; set; } = new();
    public bool DoNotDisturbEnabled { get; set; }
    public int? PreviousToastSetting { get; set; }
}
