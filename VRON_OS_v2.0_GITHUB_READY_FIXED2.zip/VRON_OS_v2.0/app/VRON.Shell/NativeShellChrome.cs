using System.Runtime.InteropServices;

namespace VRON.Shell;

/// <summary>
/// Temporarily hides Windows desktop icons and taskbars while VRON is running.
/// Every original visibility state is restored when the shell exits.
/// </summary>
internal sealed class NativeShellChrome : IDisposable
{
    private const int SW_HIDE = 0;
    private const int SW_SHOW = 5;
    private readonly Dictionary<IntPtr, bool> _previousStates = new();
    private bool _disposed;

    private delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr lParam);

    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc callback, IntPtr lParam);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr FindWindowEx(IntPtr parent, IntPtr after, string? className, string? windowName);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetClassName(IntPtr hwnd, System.Text.StringBuilder className, int maxCount);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hwnd, int command);
    [DllImport("user32.dll")] private static extern bool IsWindow(IntPtr hwnd);

    public void Hide()
    {
        if (_disposed) return;

        // Hide primary and secondary Windows taskbars. Explorer itself remains running.
        EnumWindows((hwnd, _) =>
        {
            string className = GetWindowClass(hwnd);
            if (className is "Shell_TrayWnd" or "Shell_SecondaryTrayWnd") HideAndRemember(hwnd);
            return true;
        }, IntPtr.Zero);

        // Hide the desktop icon list view, searching both Progman and WorkerW hosts.
        EnumWindows((topLevel, _) =>
        {
            IntPtr defView = FindWindowEx(topLevel, IntPtr.Zero, "SHELLDLL_DefView", null);
            if (defView != IntPtr.Zero)
            {
                IntPtr listView = FindWindowEx(defView, IntPtr.Zero, "SysListView32", "FolderView");
                if (listView != IntPtr.Zero) HideAndRemember(listView);
            }
            return true;
        }, IntPtr.Zero);
    }

    private void HideAndRemember(IntPtr hwnd)
    {
        if (hwnd == IntPtr.Zero) return;
        if (!_previousStates.ContainsKey(hwnd))
            _previousStates[hwnd] = IsWindowVisible(hwnd);
        _ = ShowWindow(hwnd, SW_HIDE);
    }

    private static string GetWindowClass(IntPtr hwnd)
    {
        var buffer = new System.Text.StringBuilder(128);
        _ = GetClassName(hwnd, buffer, buffer.Capacity);
        return buffer.ToString();
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        foreach ((IntPtr hwnd, bool wasVisible) in _previousStates)
        {
            if (IsWindow(hwnd)) _ = ShowWindow(hwnd, wasVisible ? SW_SHOW : SW_HIDE);
        }
        _previousStates.Clear();
    }
}
