using Microsoft.Win32;
using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace VRON.Shell;

public partial class MainWindow : Window
{
    private const int WH_KEYBOARD_LL = 13;
    private const int WM_KEYDOWN = 0x0100;
    private const int WM_KEYUP = 0x0101;
    private const int WM_SYSKEYDOWN = 0x0104;
    private const int WM_SYSKEYUP = 0x0105;
    private const int WM_HOTKEY = 0x0312;
    private const int VK_LWIN = 0x5B;
    private const int VK_RWIN = 0x5C;
    private const int VK_SPACE = 0x20;
    private const int VK_C = 0x43;
    private const int VK_Q = 0x51;
    private const int VK_S = 0x53;
    private const int VK_R = 0x52;
    private const int VK_MEDIA_NEXT_TRACK = 0xB0;
    private const int VK_MEDIA_PREV_TRACK = 0xB1;
    private const int VK_MEDIA_PLAY_PAUSE = 0xB3;
    private const int VK_SHIFT = 0x10;
    private const int VK_MENU = 0x12;
    private const int HOTKEY_FALLBACK = 0x5652;
    private const int HOTKEY_CONTROL_CENTER = 0x5653;
    private const int HOTKEY_EXIT = 0x5654;
    private const uint MOD_ALT = 0x0001;
    private const uint MOD_CONTROL = 0x0002;
    private const uint MOD_SHIFT = 0x0004;
    private const uint MOD_WIN = 0x0008;
    private const uint MOD_NOREPEAT = 0x4000;
    private const uint LLKHF_INJECTED = 0x10;
    private const uint INPUT_KEYBOARD = 1;
    private const uint KEYEVENTF_KEYUP = 0x0002;
    private const int SW_SHOW = 5;
    private const int SW_HIDE = 0;
    private const int WM_SETTINGCHANGE = 0x001A;
    private const uint SMTO_ABORTIFHUNG = 0x0002;

    private const string Midnight = "#071525";
    private const string Surface = "#10253D";
    private const string SurfaceRaised = "#17314C";
    private const string Pumpkin = "#F28C28";
    private const string PumpkinLight = "#FFB45E";
    private const string TextMain = "#EDF4FC";
    private const string TextMuted = "#9BAEC2";

    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct KBDLLHOOKSTRUCT
    {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT { public uint type; public InputUnion U; }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion { [FieldOffset(0)] public KEYBDINPUT ki; }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc callback, IntPtr module, uint threadId);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnhookWindowsHookEx(IntPtr hook);
    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hook, int code, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);
    [DllImport("user32.dll")]
    private static extern bool UnregisterHotKey(IntPtr window, int id);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint count, INPUT[] inputs, int size);
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string? moduleName);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr SendMessageTimeout(IntPtr hwnd, int message, IntPtr wParam, string lParam, uint flags, uint timeout, out IntPtr result);

    private readonly List<AppEntry> _apps = new();
    private readonly string _settingsPath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "VRON", "settings.json");
    private readonly NativeShellChrome _nativeChrome = new();
    private VronSettings _settings = new();
    private HwndSource? _source;
    private IntPtr _keyboardHook;
    private LowLevelKeyboardProc? _hookDelegate;
    private bool _winKeyHeld;
    private bool _winComboInProgress;
    private int _heldWinKey = VK_LWIN;
    private bool _fallbackHotkeyRegistered;
    private bool _controlCenterHotkeyRegistered;
    private bool _exitHotkeyRegistered;
    private Window? _dockWindow;
    private Window? _edgeHandleWindow;
    private Window? _drawerWindow;
    private Window? _backdropWindow;
    private Window? _quickWindow;
    private Window? _optimizerWindow;
    private TextBox? _searchBox;
    private WrapPanel? _appGrid;
    private TextBlock? _drawerClock;
    private TextBlock? _drawerDate;
    private TextBlock? _quickClock;
    private TextBlock? _quickDate;
    private TextBlock? _networkRateText;
    private TextBlock? _brightnessStatus;
    private TextBlock? _dndLabel;
    private Button? _dndButton;
    private TextBlock? _optimizerMetrics;
    private Button? _muteButton;
    private Slider? _volumeSlider;
    private Slider? _brightnessSlider;
    private DispatcherTimer? _networkTimer;
    private DispatcherTimer? _drawerClockTimer;
    private DispatcherTimer? _optimizerTimer;
    private DispatcherTimer? _chromeTimer;
    private bool _syncingSliders;
    private bool _drawerMaximized;
    private bool _quickMaximized;
    private bool _optimizerMaximized;
    private long _lastBytesIn;
    private long _lastBytesOut;
    private DateTime _lastNetworkSample;
    private Point _edgePressPoint;
    private bool _edgePullTriggered;

    public MainWindow()
    {
        InitializeComponent();
    }

    public void InitializeShell()
    {
        IntPtr handle = new WindowInteropHelper(this).EnsureHandle();
        _source = HwndSource.FromHwnd(handle);
        _source?.AddHook(WindowMessageHook);
        LoadSettings();
        LoadAppCatalog();
        ApplyDoNotDisturbAtStartup();

        _hookDelegate = KeyboardHook;
        _keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, _hookDelegate, GetModuleHandle(null), 0);
        if (_keyboardHook == IntPtr.Zero)
            _fallbackHotkeyRegistered = RegisterHotKey(handle, HOTKEY_FALLBACK, MOD_WIN | MOD_NOREPEAT, VK_SPACE);

        _controlCenterHotkeyRegistered = RegisterHotKey(handle, HOTKEY_CONTROL_CENTER, MOD_CONTROL | MOD_ALT | MOD_SHIFT | MOD_NOREPEAT, VK_C);
        _exitHotkeyRegistered = RegisterHotKey(handle, HOTKEY_EXIT, MOD_CONTROL | MOD_ALT | MOD_SHIFT | MOD_NOREPEAT, VK_Q);

        // Clean desktop by default while VRON is active; the original visibility is restored on exit.
        _nativeChrome.Hide();
        // Re-hide a newly recreated taskbar if the standard shell restarts while VRON is active.
        _chromeTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromSeconds(5) };
        _chromeTimer.Tick += (_, _) => _nativeChrome.Hide();
        _chromeTimer.Start();
        try
        {
            CreateDock();
            CreateEdgeHandle();
        }
        catch
        {
            _nativeChrome.Dispose();
            throw;
        }
    }

    private void LoadSettings()
    {
        try
        {
            if (File.Exists(_settingsPath))
                _settings = JsonSerializer.Deserialize<VronSettings>(File.ReadAllText(_settingsPath)) ?? new VronSettings();
        }
        catch
        {
            _settings = new VronSettings();
        }
        _settings.PinnedApps ??= new List<string> { "Inventory", "Notes", "CMD", "Panel" };
        _settings.PinnedAppTargets ??= new List<string>();
        _settings.HiddenBuiltInApps ??= new List<string>();
        _settings.RenamedApps ??= new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        _settings.CustomApps ??= new List<AppEntry>();
    }

    private void SaveSettings()
    {
        try
        {
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(_settingsPath)!);
            _settings.PinnedApps = _apps.Where(a => a.Pinned).Select(a => a.Name).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            _settings.PinnedAppTargets = _apps.Where(a => a.Pinned).Select(a => a.Target).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            _settings.CustomApps = _apps.Where(a => a.Custom).ToList();
            string temp = _settingsPath + ".tmp";
            File.WriteAllText(temp, JsonSerializer.Serialize(_settings, new JsonSerializerOptions { WriteIndented = true }));
            File.Move(temp, _settingsPath, true);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"VRON could not save your dock layout.\n\n{ex.Message}", "VRON", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void LoadAppCatalog()
    {
        _apps.Clear();
        IEnumerable<string> pinned = _settings.PinnedApps ?? new List<string>();
        IEnumerable<string> pinnedTargets = _settings.PinnedAppTargets ?? new List<string>();
        List<AppEntry> builtIns = new()
        {
            new AppEntry("Inventory", "\uE8B7", "System", "shell:MyComputerFolder", "", pinned.Contains("Inventory", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("Hell", "\uE74D", "System", "shell:RecycleBinFolder", "", pinned.Contains("Hell", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("Canvas", "\uE771", "Creative", "mspaint.exe", "", pinned.Contains("Canvas", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("CMD", "\uE756", "Tools", "cmd.exe", "", pinned.Contains("CMD", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("Panel", "\uE713", "System", "control.exe", "", pinned.Contains("Panel", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("PowerShell", "\uE756", "Tools", "powershell.exe", "", pinned.Contains("PowerShell", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("Cam", "\uE722", "Media", "microsoft.windows.camera:", "", pinned.Contains("Cam", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("Microsoft Store", "\uE719", "System", "ms-windows-store:", "", pinned.Contains("Microsoft Store", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("Notes", "\uE70B", "Productivity", "notepad.exe", "", pinned.Contains("Notes", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("Gallery", "\uE91B", "Media", "ms-photos:", "", pinned.Contains("Gallery", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("Timeline", "\uE787", "Productivity", "outlookcal:", "", pinned.Contains("Timeline", StringComparer.OrdinalIgnoreCase)),
            new AppEntry("Time", "\uE823", "Productivity", "ms-clock:", "", pinned.Contains("Time", StringComparer.OrdinalIgnoreCase)),
            // This is a removable shortcut only. VRON does not install or package a browser.
            new AppEntry("Browser", "\uE774", "Internet", "browser", "", pinned.Contains("Browser", StringComparer.OrdinalIgnoreCase)),
        };

        HashSet<string> hidden = new(_settings.HiddenBuiltInApps ?? new List<string>(), StringComparer.OrdinalIgnoreCase);
        foreach (AppEntry app in builtIns)
        {
            app.Pinned = pinnedTargets.Contains(app.Target, StringComparer.OrdinalIgnoreCase) || pinned.Contains(app.Name, StringComparer.OrdinalIgnoreCase);
            if (hidden.Contains(app.Name) || hidden.Contains(app.Target)) continue;
            if (_settings.RenamedApps.TryGetValue(app.Target, out string? renamed) && !string.IsNullOrWhiteSpace(renamed))
                app.Name = renamed.Trim();
            _apps.Add(app);
        }

        foreach (AppEntry custom in _settings.CustomApps ?? new List<AppEntry>())
        {
            if (!string.IsNullOrWhiteSpace(custom.Name) && !string.IsNullOrWhiteSpace(custom.Target))
            {
                custom.Custom = true;
                custom.Category = "Custom";
                custom.Pinned = pinnedTargets.Contains(custom.Target, StringComparer.OrdinalIgnoreCase) || pinned.Contains(custom.Name, StringComparer.OrdinalIgnoreCase);
                _apps.Add(custom);
            }
        }
    }

    private IntPtr WindowMessageHook(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (message == WM_HOTKEY)
        {
            int id = wParam.ToInt32();
            if (id == HOTKEY_FALLBACK) { ToggleDrawer(); handled = true; }
            else if (id == HOTKEY_CONTROL_CENTER) { ToggleQuickControls(); handled = true; }
            else if (id == HOTKEY_EXIT) { ExitVRON(); handled = true; }
        }
        return IntPtr.Zero;
    }

    // A solo Windows-key tap opens the app drawer. Win+other-key combinations pass through normally.
    private IntPtr KeyboardHook(int code, IntPtr wParam, IntPtr lParam)
    {
        if (code >= 0)
        {
            KBDLLHOOKSTRUCT key = Marshal.PtrToStructure<KBDLLHOOKSTRUCT>(lParam);
            if ((key.flags & LLKHF_INJECTED) == 0)
            {
                int message = wParam.ToInt32();
                bool isDown = message == WM_KEYDOWN || message == WM_SYSKEYDOWN;
                bool isUp = message == WM_KEYUP || message == WM_SYSKEYUP;
                bool isWin = key.vkCode == VK_LWIN || key.vkCode == VK_RWIN;

                if (isWin && isDown)
                {
                    if (!_winKeyHeld)
                    {
                        _winKeyHeld = true;
                        _winComboInProgress = false;
                        _heldWinKey = (int)key.vkCode;
                    }
                    return new IntPtr(1);
                }

                if (isWin && isUp && _winKeyHeld)
                {
                    if (_winComboInProgress) SendSyntheticWinKey(_heldWinKey, keyUp: true);
                    else Dispatcher.BeginInvoke(new Action(ToggleDrawer));
                    _winKeyHeld = false;
                    _winComboInProgress = false;
                    return new IntPtr(1);
                }

                if (_winKeyHeld && isDown && !_winComboInProgress && !isWin)
                {
                    _winComboInProgress = true;
                    SendSyntheticWinKey(_heldWinKey, keyUp: false);
                }
            }
        }
        return CallNextHookEx(_keyboardHook, code, wParam, lParam);
    }

    private static void SendSyntheticWinKey(int key, bool keyUp)
    {
        INPUT input = new()
        {
            type = INPUT_KEYBOARD,
            U = new InputUnion
            {
                ki = new KEYBDINPUT
                {
                    wVk = (ushort)key,
                    wScan = 0,
                    dwFlags = keyUp ? KEYEVENTF_KEYUP : 0,
                    time = 0,
                    dwExtraInfo = IntPtr.Zero
                }
            }
        };
        _ = SendInput(1, new[] { input }, Marshal.SizeOf<INPUT>());
    }

    private void CreateDock()
    {
        _dockWindow = new Window
        {
            Width = CalculateDockWidth(),
            Height = 78,
            WindowStyle = WindowStyle.None,
            ResizeMode = ResizeMode.NoResize,
            Background = Brush("#00071525"),
            ShowInTaskbar = false,
            ShowActivated = false,
            Topmost = true,
            AllowsTransparency = true,
            WindowStartupLocation = WindowStartupLocation.Manual,
            Content = BuildDockContent()
        };
        PlaceDock();
        _dockWindow.Show();
    }

    private void CreateEdgeHandle()
    {
        // A tiny right-edge grab strip opens Control Center without keeping a polling loop alive.
        Border grip = new()
        {
            Width = 4,
            Height = 74,
            CornerRadius = new CornerRadius(5),
            Background = Brush("#80F28C28"),
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center
        };
        _edgeHandleWindow = new Window
        {
            Width = 14,
            Height = 88,
            WindowStyle = WindowStyle.None,
            ResizeMode = ResizeMode.NoResize,
            AllowsTransparency = true,
            Background = Brushes.Transparent,
            ShowInTaskbar = false,
            ShowActivated = false,
            Topmost = true,
            WindowStartupLocation = WindowStartupLocation.Manual,
            Content = grip
        };
        _edgeHandleWindow.Left = SystemParameters.PrimaryScreenWidth - 14;
        _edgeHandleWindow.Top = (SystemParameters.PrimaryScreenHeight - _edgeHandleWindow.Height) / 2;
        grip.MouseEnter += (_, _) => grip.Background = Brush(PumpkinLight);
        grip.MouseLeave += (_, _) => grip.Background = Brush("#80F28C28");
        grip.MouseLeftButtonDown += (_, e) =>
        {
            _edgePressPoint = e.GetPosition(grip);
            _edgePullTriggered = false;
            grip.CaptureMouse();
            e.Handled = true;
        };
        grip.MouseMove += (_, e) =>
        {
            if (grip.IsMouseCaptured && e.LeftButton == MouseButtonState.Pressed)
            {
                Point current = e.GetPosition(grip);
                if (current.X - _edgePressPoint.X <= -14)
                {
                    _edgePullTriggered = true;
                    grip.ReleaseMouseCapture();
                    ToggleQuickControls();
                    e.Handled = true;
                }
            }
        };
        grip.MouseLeftButtonUp += (_, e) =>
        {
            if (grip.IsMouseCaptured) grip.ReleaseMouseCapture();
            if (!_edgePullTriggered) ToggleQuickControls();
            e.Handled = true;
        };
        _edgeHandleWindow.Show();
    }

    private double CalculateDockWidth()
    {
        double screenLimit = Math.Max(220, SystemParameters.PrimaryScreenWidth - 24);
        return Math.Min(screenLimit, Math.Max(250, 166 + _apps.Count(a => a.Pinned) * 58));
    }

    private UIElement BuildDockContent()
    {
        StackPanel row = new() { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        AddDockButton(row, "\uE80F", "All apps", ToggleDrawer, true, CreateLauncherContextMenu());
        AddDockSeparator(row);
        foreach (AppEntry app in _apps.Where(a => a.Pinned))
        {
            ContextMenu context = new();
            var remove = new MenuItem { Header = "Remove from dock" };
            remove.Click += (_, _) => { app.Pinned = false; SaveSettings(); RefreshDock(); };
            context.Items.Add(remove);
            AddDockButton(row, app.Glyph, app.Name, () => Launch(app), false, context, GetAppIconPath(app));
        }
        AddDockSeparator(row);
        AddDockButton(row, "\uE713", "Control Center", ToggleQuickControls, false);

        ScrollViewer dockScroll = new()
        {
            Content = row,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden,
            VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
            CanContentScroll = false
        };
        dockScroll.PreviewMouseWheel += (_, e) =>
        {
            dockScroll.ScrollToHorizontalOffset(dockScroll.HorizontalOffset - e.Delta);
            e.Handled = true;
        };
        return new Border
        {
            Background = Brush("#55071525"),
            CornerRadius = new CornerRadius(25),
            Padding = new Thickness(9, 8, 9, 8),
            Child = dockScroll
        };
    }

    private ContextMenu CreateLauncherContextMenu()
    {
        ContextMenu menu = new();
        var resetApps = new MenuItem { Header = "Restore hidden apps and original names" };
        resetApps.Click += (_, _) =>
        {
            _settings.HiddenBuiltInApps.Clear();
            _settings.RenamedApps.Clear();
            SaveSettings();
            LoadAppCatalog();
            RefreshAppGrid();
            RefreshDock();
        };
        menu.Items.Add(resetApps);
        var exit = new MenuItem { Header = "Exit VRON and restore desktop" };
        exit.Click += (_, _) => ExitVRON();
        menu.Items.Add(exit);
        return menu;
    }

    private void RefreshDock()
    {
        if (_dockWindow == null) return;
        _dockWindow.Content = BuildDockContent();
        _dockWindow.Width = CalculateDockWidth();
        PlaceDock();
    }

    private void PlaceDock()
    {
        if (_dockWindow == null) return;
        _dockWindow.Left = (SystemParameters.PrimaryScreenWidth - _dockWindow.Width) / 2;
        _dockWindow.Top = SystemParameters.PrimaryScreenHeight - _dockWindow.Height - 12;
    }

    private static string? GetAppIconPath(AppEntry app)
    {
        string? key = app.Target switch
        {
            "shell:MyComputerFolder" => "inventory",
            "shell:RecycleBinFolder" => "hell",
            "mspaint.exe" => "canvas",
            "cmd.exe" => "cmd",
            "control.exe" => "panel",
            "powershell.exe" => "powershell",
            "microsoft.windows.camera:" => "cam",
            "ms-windows-store:" => "store",
            "notepad.exe" => "notes",
            "ms-photos:" => "gallery",
            "outlookcal:" => "timeline",
            "ms-clock:" => "time",
            "browser" => "browser",
            "ms-settings:" => "settings",
            "taskmgr.exe" => "taskmgr",
            "devmgmt" => "device",
            "vron:optimizer" => "optimizer",
            _ => null
        };
        if (key == null) return null;
        string path = System.IO.Path.Combine(AppContext.BaseDirectory, "Assets", "Icons", key + ".png");
        return File.Exists(path) ? path : null;
    }

    private static BitmapImage LoadIconImage(string path)
    {
        BitmapImage image = new();
        image.BeginInit();
        image.CacheOption = BitmapCacheOption.OnLoad;
        image.UriSource = new Uri(path, UriKind.Absolute);
        image.EndInit();
        image.Freeze();
        return image;
    }

    private UIElement CreateAppIcon(AppEntry app, double size)
    {
        string? path = GetAppIconPath(app);
        if (path != null)
            return new Image { Source = LoadIconImage(path), Width = size, Height = size, Stretch = Stretch.Uniform };
        return new TextBlock { Text = app.Glyph, FontFamily = ResolveIconFont(), FontSize = size * 0.52,
            Foreground = Brush(app.Pinned ? PumpkinLight : TextMain), HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center, TextAlignment = TextAlignment.Center };
    }

    private void AddDockButton(Panel parent, string glyph, string tooltip, Action action, bool accent = false, ContextMenu? menu = null, string? iconPath = null)
    {
        Button button = new()
        {
            Content = iconPath != null
                ? new Image { Source = LoadIconImage(iconPath), Width = 40, Height = 40, Stretch = Stretch.Uniform }
                : new TextBlock
                {
                    Text = glyph,
                    FontFamily = ResolveIconFont(),
                    FontSize = 23,
                    FontWeight = FontWeights.Normal,
                    TextAlignment = TextAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center
                },
            Width = 50,
            Height = 52,
            Margin = new Thickness(2, 0, 2, 0),
            Foreground = Brush(accent ? PumpkinLight : TextMain),
            Background = Brush("#0010253D"),
            BorderThickness = new Thickness(0),
            ToolTip = tooltip,
            Cursor = Cursors.Hand,
            FocusVisualStyle = null,
            ContextMenu = menu
        };
        button.Template = ButtonTemplate(14);
        button.MouseEnter += (_, _) => button.Background = Brush("#35F28C28");
        button.MouseLeave += (_, _) => button.Background = Brush("#0010253D");
        button.Click += (_, _) => action();
        parent.Children.Add(button);
    }

    private static void AddDockSeparator(Panel parent)
    {
        parent.Children.Add(new Border
        {
            Width = 1,
            Height = 31,
            Background = Brush("#477A8FA7"),
            Margin = new Thickness(7, 0, 7, 0),
            VerticalAlignment = VerticalAlignment.Center
        });
    }

    private void CreateBackdrop()
    {
        if (_backdropWindow != null) return;
        _backdropWindow = new Window
        {
            Left = SystemParameters.VirtualScreenLeft,
            Top = SystemParameters.VirtualScreenTop,
            Width = SystemParameters.VirtualScreenWidth,
            Height = SystemParameters.VirtualScreenHeight,
            WindowStyle = WindowStyle.None,
            ResizeMode = ResizeMode.NoResize,
            ShowInTaskbar = false,
            ShowActivated = false,
            Topmost = true,
            Background = Brush("#88030B16"),
            Content = new Border { Background = Brush("#88030B16") }
        };
        _backdropWindow.SourceInitialized += (_, _) => NativeAcrylic.TryEnable(new WindowInteropHelper(_backdropWindow).Handle, 160);
        _backdropWindow.MouseLeftButtonDown += (_, _) => CloseDrawer();
    }

    private void CreateDrawer()
    {
        Grid root = new();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        Grid header = new() { Margin = new Thickness(2, 0, 2, 18) };
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        StackPanel controls = CreateMacControls(() => CloseDrawer(), () => MinimizeWindow(_drawerWindow), () => ToggleMaximize(_drawerWindow, ref _drawerMaximized));
        Grid.SetColumn(controls, 0);
        header.Children.Add(controls);

        StackPanel brand = new() { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(22, 0, 0, 0) };
        brand.Children.Add(new TextBlock { Text = "VRON", FontSize = 24, FontWeight = FontWeights.Bold, Foreground = Brush(PumpkinLight) });
        brand.Children.Add(new TextBlock { Text = "APPLICATIONS  /  YOUR DESKTOP, YOUR FLOW", FontSize = 9, Foreground = Brush(TextMuted), Margin = new Thickness(1, 3, 0, 0) });
        Grid.SetColumn(brand, 1);
        header.Children.Add(brand);

        StackPanel clock = new() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };
        _drawerClock = new TextBlock { Text = DateTime.Now.ToString("h:mm:ss tt"), FontSize = 17, FontWeight = FontWeights.SemiBold, Foreground = Brush(TextMain), HorizontalAlignment = HorizontalAlignment.Right };
        _drawerDate = new TextBlock { Text = DateTime.Now.ToString("ddd, d MMM yyyy"), FontSize = 10, Foreground = Brush(TextMuted), HorizontalAlignment = HorizontalAlignment.Right };
        clock.Children.Add(_drawerClock);
        clock.Children.Add(_drawerDate);
        Grid.SetColumn(clock, 2);
        header.Children.Add(clock);
        root.Children.Add(header);

        Grid searchRow = new() { Margin = new Thickness(0, 0, 0, 17), Height = 46 };
        searchRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(42) });
        searchRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        searchRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        Border searchIcon = new() { Background = Brush("#1A3552"), CornerRadius = new CornerRadius(13, 0, 0, 13), Child = new TextBlock { Text = "\uE721", FontFamily = ResolveIconFont(), FontSize = 17, Foreground = Brush(PumpkinLight), VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center } };
        searchRow.Children.Add(searchIcon);
        _searchBox = new TextBox
        {
            FontSize = 14,
            Foreground = Brush(TextMain),
            Background = Brush("#1A3552"),
            BorderThickness = new Thickness(0),
            CaretBrush = Brush(PumpkinLight),
            VerticalContentAlignment = VerticalAlignment.Center,
            Padding = new Thickness(0, 0, 12, 0),
            ToolTip = "Search apps. Press Enter to open the first match."
        };
        _searchBox.TextChanged += (_, _) => RefreshAppGrid();
        _searchBox.KeyDown += SearchKeyDown;
        Grid.SetColumn(_searchBox, 1);
        searchRow.Children.Add(_searchBox);
        Button addApp = CreateTextButton("＋  Add app", Pumpkin, TextMain, 12);
        addApp.Margin = new Thickness(10, 0, 0, 0);
        addApp.Click += (_, _) => AddCustomApp();
        Grid.SetColumn(addApp, 2);
        searchRow.Children.Add(addApp);
        Grid.SetRow(searchRow, 1);
        root.Children.Add(searchRow);

        _appGrid = new WrapPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
        ScrollViewer scroll = new()
        {
            Content = _appGrid,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Background = Brushes.Transparent
        };
        Grid.SetRow(scroll, 2);
        root.Children.Add(scroll);

        Border outer = new()
        {
            Background = Brush("#E20A1B2E"),
            BorderBrush = Brush("#36A9C8E4"),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(25),
            Padding = new Thickness(27, 24, 27, 24),
            Child = root
        };
        _drawerWindow = new Window
        {
            Width = 850,
            Height = 660,
            MinWidth = 620,
            MinHeight = 480,
            WindowStyle = WindowStyle.None,
            ResizeMode = ResizeMode.CanResize,
            Background = Brush(Midnight),
            ShowInTaskbar = false,
            Topmost = true,
            WindowStartupLocation = WindowStartupLocation.Manual,
            Content = outer
        };
        _drawerWindow.SourceInitialized += (_, _) => NativeAcrylic.TryEnable(new WindowInteropHelper(_drawerWindow).Handle, 218);
        _drawerWindow.Deactivated += (_, _) => CloseDrawer();
        _drawerClockTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromSeconds(1) };
        _drawerClockTimer.Tick += (_, _) => UpdateClockLabels();
        RefreshAppGrid();
    }

    private void RefreshAppGrid()
    {
        if (_appGrid == null) return;
        _appGrid.Children.Clear();
        string query = _searchBox?.Text.Trim() ?? string.Empty;
        IEnumerable<AppEntry> visible = _apps;
        if (!string.IsNullOrWhiteSpace(query))
            visible = visible.Where(app => app.Name.Contains(query, StringComparison.OrdinalIgnoreCase) || app.Category.Contains(query, StringComparison.OrdinalIgnoreCase));

        foreach (AppEntry app in visible.OrderBy(a => a.Name, StringComparer.OrdinalIgnoreCase))
        {
            StackPanel item = new() { Orientation = Orientation.Vertical, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            Border iconSurface = new()
            {
                Width = 56,
                Height = 56,
                CornerRadius = new CornerRadius(18),
                Background = Brush("#0010253D"),
                Child = CreateAppIcon(app, 54)
            };
            item.Children.Add(iconSurface);
            item.Children.Add(new TextBlock { Text = app.Name, FontSize = 11, FontWeight = FontWeights.Medium, Foreground = Brush(TextMain), Margin = new Thickness(0, 8, 0, 0), TextAlignment = TextAlignment.Center, TextTrimming = TextTrimming.CharacterEllipsis, Width = 100 });

            Button card = new()
            {
                Content = item,
                Width = 112,
                Height = 112,
                Margin = new Thickness(5),
                Background = Brush("#0010253D"),
                BorderThickness = new Thickness(0),
                Cursor = Cursors.Hand,
                FocusVisualStyle = null,
                ToolTip = app.Custom ? $"{app.Name} · Custom app" : app.Name
            };
            card.Template = ButtonTemplate(16);
            card.MouseEnter += (_, _) => { card.Background = Brush("#263E5B78"); iconSurface.Background = Brush("#52F28C28"); };
            card.MouseLeave += (_, _) => { card.Background = Brush("#0010253D"); iconSurface.Background = Brush(app.Pinned ? "#3AF28C28" : "#263B5874"); };
            card.Click += (_, _) => Launch(app);
            card.ContextMenu = BuildAppContextMenu(app);
            _appGrid.Children.Add(card);
        }

        if (_appGrid.Children.Count == 0)
            _appGrid.Children.Add(new TextBlock { Text = "No matching applications. Press Add app to add a program.", Foreground = Brush(TextMuted), Margin = new Thickness(8, 20, 0, 0), FontSize = 13 });
    }

    private ContextMenu BuildAppContextMenu(AppEntry app)
    {
        ContextMenu menu = new() { Background = Brush(Surface), Foreground = Brush(TextMain), Padding = new Thickness(6) };
        var rename = new MenuItem { Header = "Rename in VRON" };
        rename.Click += (_, _) =>
        {
            string? newName = PromptForAppName(app.Name);
            if (string.IsNullOrWhiteSpace(newName)) return;
            newName = newName.Trim();
            if (app.Custom) app.Name = newName;
            else _settings.RenamedApps[app.Target] = newName;
            app.Name = newName;
            SaveSettings();
            RefreshAppGrid();
            RefreshDock();
        };
        menu.Items.Add(rename);

        var pin = new MenuItem { Header = app.Pinned ? "Remove from dock" : "Pin to dock" };
        pin.Click += (_, _) => { app.Pinned = !app.Pinned; SaveSettings(); RefreshAppGrid(); RefreshDock(); };
        menu.Items.Add(pin);

        var remove = new MenuItem { Header = app.Custom ? "Delete custom shortcut" : "Remove from VRON" };
        remove.Click += (_, _) =>
        {
            _apps.Remove(app);
            if (app.Custom)
                _settings.CustomApps.RemoveAll(a => a.Target.Equals(app.Target, StringComparison.OrdinalIgnoreCase));
            else if (!_settings.HiddenBuiltInApps.Contains(app.Target, StringComparer.OrdinalIgnoreCase))
                _settings.HiddenBuiltInApps.Add(app.Target);
            SaveSettings();
            RefreshAppGrid();
            RefreshDock();
        };
        menu.Items.Add(remove);
        return menu;
    }

    private string? PromptForAppName(string currentName)
    {
        Window dialog = new()
        {
            Title = "Edit app name",
            Width = 340,
            Height = 172,
            WindowStartupLocation = _drawerWindow != null ? WindowStartupLocation.CenterOwner : WindowStartupLocation.CenterScreen,
            Owner = _drawerWindow,
            ResizeMode = ResizeMode.NoResize,
            WindowStyle = WindowStyle.None,
            Background = Brush(Midnight),
            ShowInTaskbar = false,
            Content = null
        };
        StackPanel panel = new() { Margin = new Thickness(18) };
        panel.Children.Add(new TextBlock { Text = "APP DISPLAY NAME", Foreground = Brush(PumpkinLight), FontWeight = FontWeights.Bold, FontSize = 12, Margin = new Thickness(0, 0, 0, 10) });
        TextBox input = new() { Text = currentName, FontSize = 14, Padding = new Thickness(10, 7, 10, 7), Background = Brush(Surface), Foreground = Brush(TextMain), BorderThickness = new Thickness(0) };
        panel.Children.Add(input);
        StackPanel actions = new() { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
        Button cancel = CreateTextButton("Cancel", SurfaceRaised, TextMain, 11);
        cancel.Margin = new Thickness(0, 0, 7, 0);
        cancel.Click += (_, _) => dialog.DialogResult = false;
        Button save = CreateTextButton("Save", Pumpkin, Midnight, 11);
        save.Click += (_, _) => dialog.DialogResult = true;
        actions.Children.Add(cancel); actions.Children.Add(save); panel.Children.Add(actions);
        dialog.Content = new Border { CornerRadius = new CornerRadius(16), BorderBrush = Brush("#557D93AA"), BorderThickness = new Thickness(1), Child = panel };
        dialog.Loaded += (_, _) => { input.Focus(); input.SelectAll(); };
        return dialog.ShowDialog() == true ? input.Text : null;
    }

    private void AddCustomApp()
    {
        OpenFileDialog dialog = new() { Title = "Choose an application", Filter = "Application files (*.exe)|*.exe", CheckFileExists = true };
        if (dialog.ShowDialog() != true) return;
        string name = System.IO.Path.GetFileNameWithoutExtension(dialog.FileName);
        if (_apps.Any(a => a.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            name = $"{name} (Custom)";
        var app = new AppEntry(name, "\uE756", "Custom", dialog.FileName, "", true, true);
        _apps.Add(app);
        SaveSettings();
        RefreshAppGrid();
        RefreshDock();
    }

    private void SearchKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            CloseDrawer();
            e.Handled = true;
        }
        else if (e.Key == Key.Enter)
        {
            AppEntry? match = _apps.FirstOrDefault(a => a.Name.Contains(_searchBox?.Text.Trim() ?? string.Empty, StringComparison.OrdinalIgnoreCase));
            if (match != null) Launch(match);
            else if (!string.IsNullOrWhiteSpace(_searchBox?.Text))
            {
                string value = _searchBox.Text.Trim();
                string url = value.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || value.StartsWith("https://", StringComparison.OrdinalIgnoreCase)
                    ? value : "https://www.google.com/search?q=" + Uri.EscapeDataString(value);
                try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); CloseDrawer(); }
                catch (Exception ex) { MessageBox.Show(ex.Message, "VRON Browser", MessageBoxButton.OK, MessageBoxImage.Information); }
            }
            e.Handled = true;
        }
    }

    private void ToggleDrawer()
    {
        if (!Dispatcher.CheckAccess()) { Dispatcher.BeginInvoke(new Action(ToggleDrawer)); return; }
        if (_drawerWindow?.IsVisible == true) { CloseDrawer(); return; }
        _quickWindow?.Hide();
        StopNetworkTimer();
        if (_drawerWindow == null) CreateDrawer();
        if (_drawerWindow == null) return;
        CreateBackdrop();
        UpdateClockLabels();
        _drawerClockTimer?.Start();
        if (_searchBox != null) _searchBox.Text = string.Empty;
        RefreshAppGrid();
        _backdropWindow?.Show();
        _drawerWindow.WindowState = WindowState.Normal;
        _drawerWindow.Left = Math.Max(12, SystemParameters.PrimaryScreenWidth - _drawerWindow.Width - 18);
        _drawerWindow.Top = Math.Max(12, (SystemParameters.PrimaryScreenHeight - _drawerWindow.Height) / 2);
        _drawerWindow.Show();
        _drawerWindow.Activate();
        _searchBox?.Focus();
    }

    private void CloseDrawer()
    {
        _drawerClockTimer?.Stop();
        if (_drawerWindow?.IsVisible == true) _drawerWindow.Hide();
        if (_backdropWindow?.IsVisible == true) _backdropWindow.Hide();
    }

    private void CreateQuickControls()
    {
        Grid root = new();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        Grid header = new() { Margin = new Thickness(1, 0, 0, 15) };
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        StackPanel title = new() { VerticalAlignment = VerticalAlignment.Center };
        title.Children.Add(new TextBlock { Text = "CONTROL CENTER", FontSize = 16, FontWeight = FontWeights.Bold, Foreground = Brush(PumpkinLight) });
        title.Children.Add(new TextBlock { Text = "MIDNIGHT BLUE  ·  PUMPKIN ORANGE", FontSize = 9, Foreground = Brush(TextMuted), Margin = new Thickness(0, 3, 0, 0) });
        header.Children.Add(title);
        StackPanel controls = CreateMacControls(() => HideQuickControls(), () => MinimizeWindow(_quickWindow), () => ToggleMaximize(_quickWindow, ref _quickMaximized));
        Grid.SetColumn(controls, 1);
        header.Children.Add(controls);
        root.Children.Add(header);

        StackPanel summary = new() { Margin = new Thickness(1, 0, 1, 13) };
        Grid summaryRow = new();
        summaryRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        summaryRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        StackPanel dateStack = new();
        _quickClock = new TextBlock { Text = DateTime.Now.ToString("h:mm:ss tt"), FontSize = 23, FontWeight = FontWeights.SemiBold, Foreground = Brush(TextMain) };
        _quickDate = new TextBlock { Text = DateTime.Now.ToString("dddd, d MMMM"), FontSize = 10, Foreground = Brush(TextMuted) };
        dateStack.Children.Add(_quickClock);
        dateStack.Children.Add(_quickDate);
        summaryRow.Children.Add(dateStack);
        StackPanel network = new() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };
        network.Children.Add(new TextBlock { Text = "NETWORK", FontSize = 9, Foreground = Brush(TextMuted), HorizontalAlignment = HorizontalAlignment.Right });
        _networkRateText = new TextBlock { Text = "↓ 0 KB/s   ↑ 0 KB/s", FontSize = 10, FontWeight = FontWeights.SemiBold, Foreground = Brush(PumpkinLight), HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 4, 0, 0) };
        network.Children.Add(_networkRateText);
        Grid.SetColumn(network, 1);
        summaryRow.Children.Add(network);
        summary.Children.Add(summaryRow);
        summary.Children.Add(new Border { Height = 1, Background = Brush("#337A8FA7"), Margin = new Thickness(0, 12, 0, 0) });
        Grid.SetRow(summary, 1);
        root.Children.Add(summary);

        StackPanel body = new() { Orientation = Orientation.Vertical };
        UniformGrid tiles = new() { Columns = 2, Margin = new Thickness(-4, 0, -4, 12) };
        AddQuickTile(tiles, "Wi-Fi", "\uE701", () => OpenSettings("ms-settings:network-wifi"));
        AddQuickTile(tiles, "Airplane mode", "\uE709", () => OpenSettings("ms-settings:network-airplanemode"));
        AddQuickTile(tiles, "Hotspot", "\uE1E2", () => OpenSettings("ms-settings:network-mobilehotspot"));
        AddQuickTile(tiles, "Eye comfort", "\uE706", () => OpenSettings("ms-settings:nightlight"));
        AddQuickTile(tiles, "Dark mode", "\uE793", ToggleDarkMode);
        AddQuickTile(tiles, "Do Not Disturb", "\uE7E7", ToggleDoNotDisturb);
        AddQuickTile(tiles, "Screenshot", "\uE91B", CaptureScreenshot);
        AddQuickTile(tiles, "Screen record", "\uE714", StartScreenRecording);
        AddQuickTile(tiles, "Optimizer", "\uE9D9", ShowOptimizer);
        AddQuickTile(tiles, "Cleaner", "\uE74D", RunSafeCleaner);
        AddQuickTile(tiles, "Bluetooth", "\uE702", () => OpenSettings("ms-settings:bluetooth"));
        AddQuickTile(tiles, "Startup apps", "\uE7F4", OpenStartupManager);
        AddQuickTile(tiles, "Settings", "\uE713", () => OpenSettings("ms-settings:"));
        AddQuickTile(tiles, "System Update", "\uE72C", () => OpenSettings("ms-settings:windowsupdate"));
        AddQuickTile(tiles, "Refresh VRON", "\uE72C", RefreshVronSurface);
        body.Children.Add(tiles);
        StackPanel media = new() { Margin = new Thickness(2, 0, 2, 10) };
        media.Children.Add(new TextBlock { Text = "MEDIA CONTROL", FontSize = 9, FontWeight = FontWeights.SemiBold, Foreground = Brush(PumpkinLight), Margin = new Thickness(2, 2, 2, 6) });
        Grid mediaButtons = new();
        mediaButtons.ColumnDefinitions.Add(new ColumnDefinition());
        mediaButtons.ColumnDefinitions.Add(new ColumnDefinition());
        mediaButtons.ColumnDefinitions.Add(new ColumnDefinition());
        Button previous = CreateTextButton("Previous", "#263F5D", TextMain, 10);
        Button playPause = CreateTextButton("Play / Pause", "#71451F", TextMain, 10);
        Button next = CreateTextButton("Next", "#263F5D", TextMain, 10);
        previous.Margin = new Thickness(3); playPause.Margin = new Thickness(3); next.Margin = new Thickness(3);
        previous.Click += (_, _) => SendMediaKey(VK_MEDIA_PREV_TRACK);
        playPause.Click += (_, _) => SendMediaKey(VK_MEDIA_PLAY_PAUSE);
        next.Click += (_, _) => SendMediaKey(VK_MEDIA_NEXT_TRACK);
        mediaButtons.Children.Add(previous); mediaButtons.Children.Add(playPause); mediaButtons.Children.Add(next);
        Grid.SetColumn(playPause, 1); Grid.SetColumn(next, 2);
        media.Children.Add(mediaButtons);
        media.Children.Add(new TextBlock { Text = "Controls the active background media session when the player supports Windows media keys.", FontSize = 9, Foreground = Brush(TextMuted), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(3, 2, 3, 0) });
        body.Children.Add(media);
        body.Children.Add(new TextBlock { Text = "Screen recording uses the built-in capture feature when it is installed. DND controls notification banners for this account.", FontSize = 9, Foreground = Brush(TextMuted), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(2, -2, 2, 10) });

        body.Children.Add(CreateSliderBlock("VOLUME", "\uE767", out _volumeSlider, 0, 100));
        if (_volumeSlider != null)
        {
            _syncingSliders = true;
            if (AudioEndpoint.TryGetVolume(out float volume)) _volumeSlider.Value = volume * 100;
            _syncingSliders = false;
            _volumeSlider.PreviewMouseLeftButtonUp += (_, _) => { if (!_syncingSliders && _volumeSlider != null) _ = AudioEndpoint.TrySetVolume((float)_volumeSlider.Value / 100f); };
            _volumeSlider.KeyUp += (_, _) => { if (!_syncingSliders && _volumeSlider != null) _ = AudioEndpoint.TrySetVolume((float)_volumeSlider.Value / 100f); };
        }
        Button mute = CreateTextButton("Mute", "#263F5D", TextMain, 11);
        mute.Margin = new Thickness(0, 2, 0, 8);
        mute.HorizontalAlignment = HorizontalAlignment.Right;
        mute.Click += (_, _) =>
        {
            if (AudioEndpoint.TryToggleMute(out bool muted)) UpdateMuteButton(muted);
        };
        _muteButton = mute;
        if (AudioEndpoint.TryGetMute(out bool initialMute)) UpdateMuteButton(initialMute);
        body.Children.Add(mute);

        body.Children.Add(CreateSliderBlock("DISPLAY BRIGHTNESS", "\uE706", out _brightnessSlider, 0, 100));
        bool brightnessAvailable = MonitorBrightness.TryGetPercent(out int currentBrightness);
        if (_brightnessSlider != null)
        {
            _brightnessSlider.Value = currentBrightness;
            _brightnessSlider.IsEnabled = brightnessAvailable;
            _brightnessSlider.PreviewMouseLeftButtonUp += (_, _) =>
            {
                if (_brightnessSlider != null && !MonitorBrightness.TrySetPercent((int)_brightnessSlider.Value))
                    OpenSettings("ms-settings:display");
            };
            _brightnessSlider.KeyUp += (_, _) =>
            {
                if (_brightnessSlider != null && !MonitorBrightness.TrySetPercent((int)_brightnessSlider.Value))
                    OpenSettings("ms-settings:display");
            };
        }
        _brightnessStatus = new TextBlock { Text = brightnessAvailable ? "DDC/CI display control ready" : "Display does not expose brightness control · open Display Settings", FontSize = 9, Foreground = Brush(TextMuted), Margin = new Thickness(2, -4, 2, 10), TextWrapping = TextWrapping.Wrap };
        body.Children.Add(_brightnessStatus);

        Button eq = CreateTextButton("Bass & treble  ·  device audio enhancements", "#19314B", TextMuted, 10);
        eq.HorizontalAlignment = HorizontalAlignment.Stretch;
        eq.Margin = new Thickness(0, 1, 0, 8);
        eq.Click += (_, _) => OpenSettings("mmsys.cpl");
        body.Children.Add(eq);
        body.Children.Add(new TextBlock { Text = "Bass and treble depend on your audio driver or equalizer. VRON opens the sound-device panel instead of showing fake system-wide sliders.", FontSize = 9, Foreground = Brush(TextMuted), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(2, 0, 2, 10) });

        body.Children.Add(new TextBlock { Text = "Wi-Fi, Airplane mode, Hotspot and Eye comfort open the matching system controls. They are not forced on/off by background scripts.", FontSize = 9, Foreground = Brush(TextMuted), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(2, 0, 2, 6) });
        ScrollViewer scroll = new() { Content = body, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Background = Brushes.Transparent };
        Grid.SetRow(scroll, 2);
        root.Children.Add(scroll);

        Border outer = new()
        {
            Width = 390,
            Height = 720,
            Background = Brush("#E20A1B2E"),
            BorderBrush = Brush("#369DB7D2"),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(24),
            Padding = new Thickness(20, 18, 20, 16),
            Child = root
        };
        _quickWindow = new Window
        {
            Width = 430,
            Height = 760,
            MinWidth = 370,
            MinHeight = 560,
            WindowStyle = WindowStyle.None,
            ResizeMode = ResizeMode.CanResize,
            Background = Brush(Midnight),
            ShowInTaskbar = false,
            Topmost = true,
            WindowStartupLocation = WindowStartupLocation.Manual,
            Content = outer
        };
        _quickWindow.SourceInitialized += (_, _) => NativeAcrylic.TryEnable(new WindowInteropHelper(_quickWindow).Handle, 220);
        _quickWindow.Deactivated += (_, _) => HideQuickControls();
        _networkTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromSeconds(1) };
        _networkTimer.Tick += (_, _) => { UpdateNetworkRate(); UpdateClockLabels(); };
    }

    private UIElement CreateSliderBlock(string title, string glyph, out Slider? slider, double min, double max)
    {
        slider = new Slider { Minimum = min, Maximum = max, Value = 50, Height = 26, Margin = new Thickness(2, 2, 2, 8), IsSnapToTickEnabled = false };
        slider.Foreground = Brush(Pumpkin);
        StackPanel block = new() { Margin = new Thickness(1, 5, 1, 1) };
        StackPanel heading = new() { Orientation = Orientation.Horizontal };
        heading.Children.Add(new TextBlock { Text = glyph, FontFamily = ResolveIconFont(), FontSize = 14, Foreground = Brush(PumpkinLight), Width = 24 });
        heading.Children.Add(new TextBlock { Text = title, FontSize = 9, FontWeight = FontWeights.SemiBold, Foreground = Brush(TextMuted), VerticalAlignment = VerticalAlignment.Center });
        block.Children.Add(heading);
        block.Children.Add(slider);
        return block;
    }

    private Button AddQuickTile(Panel parent, string title, string glyph, Action action)
    {
        StackPanel content = new() { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        content.Children.Add(new TextBlock { Text = glyph, FontFamily = ResolveIconFont(), FontSize = 20, Foreground = Brush(PumpkinLight), Width = 34, VerticalAlignment = VerticalAlignment.Center });
        TextBlock label = new() { Text = title, FontSize = 11, FontWeight = FontWeights.Medium, Foreground = Brush(TextMain), VerticalAlignment = VerticalAlignment.Center };
        content.Children.Add(label);
        Button button = new() { Content = content, Height = 51, Margin = new Thickness(4), Padding = new Thickness(11, 0, 6, 0), HorizontalContentAlignment = HorizontalAlignment.Left, Background = Brush("#223A5876"), BorderThickness = new Thickness(0), Cursor = Cursors.Hand, FocusVisualStyle = null };
        button.Template = ButtonTemplate(12);
        button.MouseEnter += (_, _) => button.Background = Brush("#3AF28C28");
        button.MouseLeave += (_, _) => button.Background = Brush(_settings.DoNotDisturbEnabled && title == "Do Not Disturb" ? "#714A2C" : "#223A5876");
        button.Click += (_, _) => action();
        parent.Children.Add(button);
        if (title == "Do Not Disturb") { _dndLabel = label; _dndButton = button; RefreshDndTile(); }
        return button;
    }

    private void ToggleQuickControls()
    {
        if (!Dispatcher.CheckAccess()) { Dispatcher.BeginInvoke(new Action(ToggleQuickControls)); return; }
        if (_quickWindow?.IsVisible == true) { HideQuickControls(); return; }
        CloseDrawer();
        if (_quickWindow == null) CreateQuickControls();
        if (_quickWindow == null) return;
        UpdateClockLabels();
        double screenWidth = SystemParameters.PrimaryScreenWidth;
        double screenHeight = SystemParameters.PrimaryScreenHeight;
        _quickWindow.WindowState = WindowState.Normal;
        _quickWindow.Left = Math.Max(0, screenWidth - _quickWindow.Width - 14);
        _quickWindow.Top = Math.Max(0, screenHeight - _quickWindow.Height - 12);
        ResetNetworkSample();
        _quickWindow.Show();
        _quickWindow.Activate();
        _networkTimer?.Start();
    }

    private void HideQuickControls()
    {
        _networkTimer?.Stop();
        if (_quickWindow?.IsVisible == true) _quickWindow.Hide();
    }

    private void ResetNetworkSample()
    {
        ReadNetworkTotals(out _lastBytesIn, out _lastBytesOut);
        _lastNetworkSample = DateTime.UtcNow;
        if (_networkRateText != null) _networkRateText.Text = "↓ 0 KB/s   ↑ 0 KB/s";
    }

    private void UpdateNetworkRate()
    {
        if (_quickWindow?.IsVisible != true) { StopNetworkTimer(); return; }
        ReadNetworkTotals(out long received, out long sent);
        DateTime now = DateTime.UtcNow;
        double seconds = Math.Max(0.2, (now - _lastNetworkSample).TotalSeconds);
        double down = Math.Max(0, received - _lastBytesIn) / seconds;
        double up = Math.Max(0, sent - _lastBytesOut) / seconds;
        _lastBytesIn = received;
        _lastBytesOut = sent;
        _lastNetworkSample = now;
        if (_networkRateText != null) _networkRateText.Text = $"↓ {FormatRate(down)}   ↑ {FormatRate(up)}";
        UpdateClockLabels();
    }

    private static void ReadNetworkTotals(out long received, out long sent)
    {
        received = 0;
        sent = 0;
        try
        {
            foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus != OperationalStatus.Up || nic.NetworkInterfaceType == NetworkInterfaceType.Loopback || nic.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                IPv4InterfaceStatistics stats = nic.GetIPv4Statistics();
                received += stats.BytesReceived;
                sent += stats.BytesSent;
            }
        }
        catch { }
    }

    private static string FormatRate(double bytesPerSecond)
    {
        if (bytesPerSecond >= 1024 * 1024) return $"{bytesPerSecond / (1024 * 1024):0.0} MB/s";
        if (bytesPerSecond >= 1024) return $"{bytesPerSecond / 1024:0} KB/s";
        return $"{bytesPerSecond:0} B/s";
    }

    private void StopNetworkTimer() => _networkTimer?.Stop();

    private void UpdateMuteButton(bool muted)
    {
        if (_muteButton == null) return;
        _muteButton.Content = muted ? "Unmute system audio" : "Mute system audio";
        _muteButton.Background = Brush(muted ? "#5C341E" : "#263F5D");
    }

    private void ToggleDarkMode()
    {
        try
        {
            using RegistryKey key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", true)!;
            object? current = key.GetValue("AppsUseLightTheme");
            int next = current is int value && value == 0 ? 1 : 0;
            key.SetValue("AppsUseLightTheme", next, RegistryValueKind.DWord);
            key.SetValue("SystemUsesLightTheme", next, RegistryValueKind.DWord);
            _ = SendMessageTimeout(new IntPtr(0xffff), WM_SETTINGCHANGE, IntPtr.Zero, "ImmersiveColorSet", SMTO_ABORTIFHUNG, 1000, out _);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Could not switch the desktop theme.\n\n{ex.Message}", "VRON", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void RunSafeCleaner()
    {
        MessageBoxResult confirm = MessageBox.Show(
            "Clean files older than 14 days from your current user's Temp folder?\n\nVRON will skip folders, reparse points and files that are in use. Browser data, Prefetch, System Update cache and standby memory are left untouched.",
            "VRON Cleaner", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (confirm != MessageBoxResult.Yes) return;

        int deleted = 0;
        int skipped = 0;
        DateTime cutoff = DateTime.Now.AddDays(-14);
        string tempPath = System.IO.Path.GetTempPath();
        try
        {
            foreach (string file in Directory.EnumerateFiles(tempPath, "*", SearchOption.TopDirectoryOnly))
            {
                try
                {
                    FileInfo info = new(file);
                    if ((info.Attributes & FileAttributes.ReparsePoint) != 0 || info.LastWriteTime > cutoff) { skipped++; continue; }
                    info.Delete();
                    deleted++;
                }
                catch { skipped++; }
            }
            string logDir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VRON", "Logs");
            Directory.CreateDirectory(logDir);
            File.AppendAllText(System.IO.Path.Combine(logDir, "cleaner.log"), $"{DateTime.Now:O} | deleted={deleted} | skipped={skipped} | path={tempPath}{Environment.NewLine}");
            MessageBox.Show($"Cleaner finished.\n\nDeleted: {deleted}\nSkipped: {skipped}\n\nOnly your user Temp folder was checked.", "VRON Cleaner", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Cleaner could not finish.\n\n{ex.Message}", "VRON Cleaner", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private static FontFamily ResolveIconFont()
    {
        // Prefer the Fluent icon font when present; fall back to the compatible Win10 MDL2 font.
        bool fluent = System.Windows.Media.Fonts.SystemFontFamilies.Any(f =>
            f.Source.Equals("Segoe Fluent Icons", StringComparison.OrdinalIgnoreCase));
        return new FontFamily(fluent ? "Segoe Fluent Icons" : "Segoe MDL2 Assets");
    }

    private void ApplyDoNotDisturbAtStartup()
    {
        if (!_settings.DoNotDisturbEnabled) return;
        try
        {
            using RegistryKey key = Registry.CurrentUser.CreateSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Notifications\Settings", true)!;
            key.SetValue("NOC_GLOBAL_SETTING_TOASTS_ENABLED", 0, RegistryValueKind.DWord);
        }
        catch { /* Do Not Disturb remains an optional account preference. */ }
    }

    private void ToggleDoNotDisturb()
    {
        try
        {
            using RegistryKey key = Registry.CurrentUser.CreateSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Notifications\Settings", true)!;
            const string valueName = "NOC_GLOBAL_SETTING_TOASTS_ENABLED";
            if (!_settings.DoNotDisturbEnabled)
            {
                object? existing = key.GetValue(valueName);
                _settings.PreviousToastSetting = existing is int number ? number : 1;
                key.SetValue(valueName, 0, RegistryValueKind.DWord);
                _settings.DoNotDisturbEnabled = true;
            }
            else
            {
                key.SetValue(valueName, _settings.PreviousToastSetting ?? 1, RegistryValueKind.DWord);
                _settings.DoNotDisturbEnabled = false;
                _settings.PreviousToastSetting = null;
            }
            SaveSettings();
            RefreshDndTile();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Could not change Do Not Disturb.\n\n{ex.Message}", "VRON", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void RefreshDndTile()
    {
        if (_dndLabel != null) _dndLabel.Text = _settings.DoNotDisturbEnabled ? "Do Not Disturb · On" : "Do Not Disturb · Off";
        if (_dndButton != null) _dndButton.Background = Brush(_settings.DoNotDisturbEnabled ? "#714A2C" : "#223A5876");
    }

    private static void SendKeyChord(params int[] keys)
    {
        List<INPUT> inputs = new();
        foreach (int key in keys)
            inputs.Add(new INPUT { type = INPUT_KEYBOARD, U = new InputUnion { ki = new KEYBDINPUT { wVk = (ushort)key } } });
        foreach (int key in keys.Reverse())
            inputs.Add(new INPUT { type = INPUT_KEYBOARD, U = new InputUnion { ki = new KEYBDINPUT { wVk = (ushort)key, dwFlags = KEYEVENTF_KEYUP } } });
        _ = SendInput((uint)inputs.Count, inputs.ToArray(), Marshal.SizeOf<INPUT>());
    }

    private void CaptureScreenshot()
    {
        HideQuickControls();
        SendKeyChord(VK_LWIN, VK_SHIFT, VK_S);
    }

    private void StartScreenRecording()
    {
        HideQuickControls();
        // The LTSC image may omit Game Bar. Try to open it first; if absent, let the user add their own recorder.
        try
        {
            Process.Start(new ProcessStartInfo("ms-gamingoverlay:") { UseShellExecute = true });
            SendKeyChord(VK_LWIN, VK_MENU, VK_R);
        }
        catch
        {
            MessageBox.Show("This installation does not appear to include the built-in capture overlay. Use All Apps → Add app to add your preferred lightweight recorder. VRON does not bundle a heavy recorder.", "VRON Capture", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void OpenStartupManager() => OpenSettings("ms-settings:startupapps");

    private void ShowOptimizer()
    {
        HideQuickControls();
        if (_optimizerWindow == null) CreateOptimizerWindow();
        if (_optimizerWindow == null) return;
        _optimizerWindow.Show();
        _optimizerWindow.Activate();
        UpdateOptimizerMetrics();
        _optimizerTimer?.Start();
    }

    private void CreateOptimizerWindow()
    {
        StackPanel content = new() { Margin = new Thickness(20) };
        Grid header = new();
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        StackPanel heading = new();
        heading.Children.Add(new TextBlock { Text = "VRON OPTIMIZER", FontSize = 17, FontWeight = FontWeights.Bold, Foreground = Brush(PumpkinLight) });
        heading.Children.Add(new TextBlock { Text = "Lightweight tools · changes only when you choose", FontSize = 9, Foreground = Brush(TextMuted), Margin = new Thickness(0, 3, 0, 0) });
        header.Children.Add(heading);
        StackPanel dots = CreateMacControls(() => _optimizerWindow?.Close(), () => _optimizerWindow?.Hide(), () => ToggleMaximize(_optimizerWindow, ref _optimizerMaximized));
        Grid.SetColumn(dots, 1); header.Children.Add(dots);
        content.Children.Add(header);

        Border metrics = new()
        {
            Background = Brush("#C7162F49"), CornerRadius = new CornerRadius(16), Padding = new Thickness(14), Margin = new Thickness(0, 18, 0, 14),
            Child = new StackPanel { Children = { new TextBlock { Text = "LIVE SYSTEM LOAD", FontSize = 9, FontWeight = FontWeights.SemiBold, Foreground = Brush(PumpkinLight), Margin = new Thickness(0, 0, 0, 7) }, new TextBlock { Text = "Reading system status…", Name = "OptimizerMetricsPlaceholder", FontSize = 12, Foreground = Brush(TextMain) } } }
        };
        StackPanel metricStack = (StackPanel)metrics.Child;
        _optimizerMetrics = (TextBlock)metricStack.Children[1];
        content.Children.Add(metrics);

        AddOptimizerAction(content, "Startup & boot apps", "Review and disable unwanted startup programs using the system startup manager.", OpenStartupManager);
        AddOptimizerAction(content, "Installed app management", "Review optional apps and uninstall only the ones you recognise and no longer need.", () => OpenSettings("ms-settings:appsfeatures"));
        AddOptimizerAction(content, "Background app permissions", "Review which optional apps are allowed to run in the background.", () => OpenSettings("ms-settings:privacy-backgroundapps"));
        AddOptimizerAction(content, "Power and performance", "Choose Balanced or a performance power plan in the standard power settings.", () => OpenSettings("powercfg.cpl"));
        AddOptimizerAction(content, "Storage cleanup", "Open the built-in storage cleanup utility; review files before deleting.", () => Process.Start(new ProcessStartInfo("cleanmgr.exe") { UseShellExecute = true }));
        AddOptimizerAction(content, "RAM and processes", "Open the process manager to identify and close apps you recognise. VRON never purges standby memory.", () => Process.Start(new ProcessStartInfo("taskmgr.exe") { UseShellExecute = true }));
        AddOptimizerAction(content, "Driver & device manager", "Inspect hardware status and manage manufacturer-supplied signed drivers.", () => Process.Start(new ProcessStartInfo("mmc.exe", "devmgmt.msc") { UseShellExecute = true }));
        AddOptimizerAction(content, "Create a restore point", "Open system protection so you can create a restore point before major changes.", () => Process.Start(new ProcessStartInfo("SystemPropertiesProtection.exe") { UseShellExecute = true }));
        AddOptimizerAction(content, "Verify system files", "Run the read-only SFC verification scan (administrator approval required).", RunSystemVerification);
        AddOptimizerAction(content, "Repair system components", "Run DISM RestoreHealth followed by SFC Scannow (administrator approval required).", RunSystemRepair);
        AddOptimizerAction(content, "Clean temporary files", "Remove only old files from your user Temp folder; active files and browser data are skipped.", RunSafeCleaner);

        content.Children.Add(new TextBlock { Text = "VRON does not kill essential services, disable Defender/Firewall, empty RAM standby lists, alter bootloader settings or change the pagefile. Those tweaks can break updates, drivers, networking or make this low-end PC slower. App shortcuts can be hidden, renamed, pinned or removed from VRON; removing a shortcut does not uninstall its underlying component.", FontSize = 9, Foreground = Brush(TextMuted), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(2, 10, 2, 0) });

        ScrollViewer scroll = new() { Content = content, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Background = Brushes.Transparent };
        Border outer = new() { Width = 510, Height = 680, Background = Brush("#E20A1B2E"), BorderBrush = Brush("#369DB7D2"), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(24), Child = scroll };
        _optimizerWindow = new Window { Width = 530, Height = 700, MinWidth = 470, MinHeight = 580, WindowStyle = WindowStyle.None, ResizeMode = ResizeMode.CanResize, Background = Brush(Midnight), ShowInTaskbar = false, Topmost = true, WindowStartupLocation = WindowStartupLocation.CenterScreen, Content = outer };
        _optimizerWindow.SourceInitialized += (_, _) => NativeAcrylic.TryEnable(new WindowInteropHelper(_optimizerWindow).Handle, 220);
        _optimizerWindow.Closed += (_, _) => { _optimizerTimer?.Stop(); _optimizerWindow = null; _optimizerMetrics = null; };
        _optimizerTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromSeconds(2) };
        _optimizerTimer.Tick += (_, _) => UpdateOptimizerMetrics();
    }

    private void AddOptimizerAction(Panel parent, string title, string description, Action action)
    {
        StackPanel detail = new() { Margin = new Thickness(0, 1, 0, 1) };
        detail.Children.Add(new TextBlock { Text = title, Foreground = Brush(TextMain), FontSize = 12, FontWeight = FontWeights.SemiBold });
        detail.Children.Add(new TextBlock { Text = description, Foreground = Brush(TextMuted), FontSize = 9, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 3, 0, 0) });
        Button button = new() { Content = detail, HorizontalContentAlignment = HorizontalAlignment.Left, Padding = new Thickness(13, 9, 13, 9), Margin = new Thickness(0, 0, 0, 7), Background = Brush("#223A5876"), BorderThickness = new Thickness(0), Cursor = Cursors.Hand };
        button.Template = ButtonTemplate(12);
        button.Click += (_, _) => action();
        parent.Children.Add(button);
    }

    private void UpdateOptimizerMetrics()
    {
        if (_optimizerWindow?.IsVisible != true) { _optimizerTimer?.Stop(); return; }
        SystemMetrics.Snapshot snapshot = SystemMetrics.Read();
        string cpu = snapshot.CpuPercent.HasValue ? $"CPU  {snapshot.CpuPercent.Value:0}%" : "CPU  sampling…";
        string ram = snapshot.RamTotalGb > 0
            ? $"RAM  {snapshot.RamUsedGb:0.0} / {snapshot.RamTotalGb:0.0} GB used  ·  {snapshot.RamAvailableGb:0.0} GB available ({snapshot.RamPercent:0}%)"
            : "RAM  unavailable";
        if (_optimizerMetrics != null) _optimizerMetrics.Text = cpu + "\n" + ram;
    }

    private void RunSystemVerification()
    {
        if (MessageBox.Show("Run the read-only system file verification scan now? It may take several minutes.", "VRON System Check", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        try { Process.Start(new ProcessStartInfo("cmd.exe", "/k sfc /verifyonly") { UseShellExecute = true, Verb = "runas" }); }
        catch (Exception ex) { MessageBox.Show($"Could not start the system check.\n\n{ex.Message}", "VRON", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void RunSystemRepair()
    {
        if (MessageBox.Show("This runs DISM RestoreHealth and SFC Scannow with administrator approval. It can take a long time and may use System Update to repair files. Continue?", "VRON System Repair", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        try
        {
            Process.Start(new ProcessStartInfo("cmd.exe", "/k DISM /Online /Cleanup-Image /RestoreHealth && sfc /scannow") { UseShellExecute = true, Verb = "runas" });
        }
        catch (Exception ex) { MessageBox.Show($"Could not start system repair.\n\n{ex.Message}", "VRON", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void SendMediaKey(int virtualKey)
    {
        INPUT down = new() { type = INPUT_KEYBOARD, U = new InputUnion { ki = new KEYBDINPUT { wVk = (ushort)virtualKey } } };
        INPUT up = new() { type = INPUT_KEYBOARD, U = new InputUnion { ki = new KEYBDINPUT { wVk = (ushort)virtualKey, dwFlags = KEYEVENTF_KEYUP } } };
        _ = SendInput(2, new[] { down, up }, Marshal.SizeOf<INPUT>());
    }

    private void RefreshVronSurface()
    {
        LoadAppCatalog();
        RefreshDock();
        RefreshAppGrid();
        UpdateClockLabels();
        _ = SendMessageTimeout(new IntPtr(0xFFFF), WM_SETTINGCHANGE, IntPtr.Zero, "VRON", SMTO_ABORTIFHUNG, 1000, out _);
    }

    private void OpenSettings(string target)
    {
        try
        {
            Process.Start(new ProcessStartInfo(target) { UseShellExecute = true });
            HideQuickControls();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Could not open {target}.\n\n{ex.Message}", "VRON", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void Launch(AppEntry app)
    {
        try
        {
            if (app.Target.Equals("vron:optimizer", StringComparison.OrdinalIgnoreCase))
            {
                ShowOptimizer();
            }
            else if (app.Target.Equals("devmgmt", StringComparison.OrdinalIgnoreCase))
            {
                Process.Start(new ProcessStartInfo("mmc.exe", "devmgmt.msc") { UseShellExecute = true });
            }
            else if (app.Target == "browser")
            {
                Process.Start(new ProcessStartInfo("https://www.google.com") { UseShellExecute = true });
            }
            else if (app.Target.StartsWith("shell:", StringComparison.OrdinalIgnoreCase))
            {
                Process.Start(new ProcessStartInfo("explorer.exe", app.Target) { UseShellExecute = true });
            }
            else if (app.Target.Equals("mmsys.cpl", StringComparison.OrdinalIgnoreCase))
            {
                Process.Start(new ProcessStartInfo("control.exe", "mmsys.cpl") { UseShellExecute = true });
            }
            else if (app.Target.EndsWith(":", StringComparison.Ordinal))
            {
                Process.Start(new ProcessStartInfo(app.Target) { UseShellExecute = true });
            }
            else if (app.Target.Equals("terminal", StringComparison.OrdinalIgnoreCase))
            {
                Process.Start(new ProcessStartInfo("powershell.exe") { UseShellExecute = true });
            }
            else
            {
                Process.Start(new ProcessStartInfo(app.Target, app.Arguments) { UseShellExecute = true });
            }
            CloseDrawer();
            HideQuickControls();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Could not open {app.Name}.\n\nThe app may not be included in this VRON image.\n\n{ex.Message}", "VRON", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void UpdateClockLabels()
    {
        DateTime now = DateTime.Now;
        if (_drawerClock != null) _drawerClock.Text = now.ToString("h:mm:ss tt");
        if (_drawerDate != null) _drawerDate.Text = now.ToString("ddd, d MMM yyyy");
        if (_quickClock != null) _quickClock.Text = now.ToString("h:mm:ss tt");
        if (_quickDate != null) _quickDate.Text = now.ToString("dddd, d MMMM");
    }

    private static StackPanel CreateMacControls(Action close, Action minimize, Action maximize)
    {
        StackPanel row = new() { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        AddMacDot(row, Pumpkin, "Close", close);
        AddMacDot(row, "#C87B32", "Minimize", minimize);
        AddMacDot(row, "#5C9B83", "Maximize / restore", maximize);
        return row;
    }

    private static void AddMacDot(Panel parent, string color, string tooltip, Action action)
    {
        Ellipse dot = new() { Width = 11, Height = 11, Fill = Brush(color), StrokeThickness = 0 };
        Button button = new() { Content = dot, Width = 20, Height = 20, Margin = new Thickness(0, 0, 5, 0), Background = Brushes.Transparent, BorderThickness = new Thickness(0), Cursor = Cursors.Hand, ToolTip = tooltip, FocusVisualStyle = null };
        button.Click += (_, _) => action();
        parent.Children.Add(button);
    }

    private void MinimizeWindow(Window? window)
    {
        if (window == _drawerWindow) CloseDrawer();
        else if (window == _quickWindow) HideQuickControls();
    }

    private static void ToggleMaximize(Window? window, ref bool maximized)
    {
        if (window == null) return;
        if (!maximized)
        {
            window.WindowState = WindowState.Maximized;
            maximized = true;
        }
        else
        {
            window.WindowState = WindowState.Normal;
            maximized = false;
        }
    }

    private static Button CreateTextButton(string text, string background, string foreground, double fontSize)
    {
        Button button = new()
        {
            Content = text,
            Padding = new Thickness(12, 7, 12, 7),
            Foreground = Brush(foreground),
            Background = Brush(background),
            BorderThickness = new Thickness(0),
            FontSize = fontSize,
            Cursor = Cursors.Hand,
            FocusVisualStyle = null
        };
        button.Template = ButtonTemplate(10);
        button.MouseEnter += (_, _) => button.Opacity = 0.86;
        button.MouseLeave += (_, _) => button.Opacity = 1;
        return button;
    }

    private static ControlTemplate ButtonTemplate(double radius)
    {
        FrameworkElementFactory border = new(typeof(Border));
        border.SetValue(Border.CornerRadiusProperty, new CornerRadius(radius));
        border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Control.BackgroundProperty));
        border.SetValue(Border.SnapsToDevicePixelsProperty, true);
        FrameworkElementFactory presenter = new(typeof(ContentPresenter));
        presenter.SetValue(ContentPresenter.HorizontalAlignmentProperty, new TemplateBindingExtension(Control.HorizontalContentAlignmentProperty));
        presenter.SetValue(ContentPresenter.VerticalAlignmentProperty, new TemplateBindingExtension(Control.VerticalContentAlignmentProperty));
        presenter.SetValue(ContentPresenter.MarginProperty, new TemplateBindingExtension(Control.PaddingProperty));
        border.AppendChild(presenter);
        return new ControlTemplate(typeof(Button)) { VisualTree = border };
    }

    private static SolidColorBrush Brush(string value)
    {
        SolidColorBrush brush = new((Color)System.Windows.Media.ColorConverter.ConvertFromString(value)!);
        brush.Freeze();
        return brush;
    }

    private void RestoreDoNotDisturbOnExit()
    {
        if (!_settings.DoNotDisturbEnabled) return;
        try
        {
            using RegistryKey key = Registry.CurrentUser.CreateSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Notifications\Settings", true)!;
            key.SetValue("NOC_GLOBAL_SETTING_TOASTS_ENABLED", _settings.PreviousToastSetting ?? 1, RegistryValueKind.DWord);
            _settings.DoNotDisturbEnabled = false;
            _settings.PreviousToastSetting = null;
            SaveSettings();
        }
        catch { /* Emergency desktop recovery script also restores this setting. */ }
    }

    private void ExitVRON()
    {
        CloseDrawer();
        HideQuickControls();
        Application.Current.Shutdown();
    }

    private void OnHostClosed(object? sender, EventArgs e)
    {
        IntPtr handle = new WindowInteropHelper(this).Handle;
        if (_fallbackHotkeyRegistered) _ = UnregisterHotKey(handle, HOTKEY_FALLBACK);
        if (_controlCenterHotkeyRegistered) _ = UnregisterHotKey(handle, HOTKEY_CONTROL_CENTER);
        if (_exitHotkeyRegistered) _ = UnregisterHotKey(handle, HOTKEY_EXIT);
        if (_keyboardHook != IntPtr.Zero) _ = UnhookWindowsHookEx(_keyboardHook);
        _source?.RemoveHook(WindowMessageHook);
        RestoreDoNotDisturbOnExit();
        StopNetworkTimer();
        _drawerClockTimer?.Stop();
        _optimizerTimer?.Stop();
        _chromeTimer?.Stop();
        _nativeChrome.Dispose();
        CloseIfLoaded(_edgeHandleWindow);
        CloseIfLoaded(_dockWindow);
        CloseIfLoaded(_drawerWindow);
        CloseIfLoaded(_backdropWindow);
        CloseIfLoaded(_quickWindow);
        CloseIfLoaded(_optimizerWindow);
    }

    private static void CloseIfLoaded(Window? window)
    {
        if (window?.IsLoaded == true) window.Close();
    }
}
