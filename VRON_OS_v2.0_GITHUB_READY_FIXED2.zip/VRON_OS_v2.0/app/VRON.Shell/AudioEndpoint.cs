using System.Runtime.InteropServices;

namespace VRON.Shell;

/// <summary>Small Core Audio wrapper for master volume and mute. No polling thread is used.</summary>
internal static class AudioEndpoint
{
    private const int CLSCTX_ALL = 23;

    private enum DataFlow { Render = 0, Capture = 1, All = 2 }
    private enum Role { Console = 0, Multimedia = 1, Communications = 2 }

    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    private class MMDeviceEnumeratorComObject { }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator
    {
        [PreserveSig] int EnumAudioEndpoints(DataFlow dataFlow, uint stateMask, out IntPtr devices);
        [PreserveSig] int GetDefaultAudioEndpoint(DataFlow dataFlow, Role role, out IMMDevice device);
        [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out IMMDevice device);
        [PreserveSig] int RegisterEndpointNotificationCallback(IntPtr client);
        [PreserveSig] int UnregisterEndpointNotificationCallback(IntPtr client);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object instance);
        [PreserveSig] int OpenPropertyStore(int access, out IntPtr properties);
        [PreserveSig] int GetId(out IntPtr id);
        [PreserveSig] int GetState(out uint state);
    }

    [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioEndpointVolume
    {
        [PreserveSig] int RegisterControlChangeNotify(IntPtr notify);
        [PreserveSig] int UnregisterControlChangeNotify(IntPtr notify);
        [PreserveSig] int GetChannelCount(out uint channelCount);
        [PreserveSig] int SetMasterVolumeLevel(float levelDb, ref Guid eventContext);
        [PreserveSig] int SetMasterVolumeLevelScalar(float level, ref Guid eventContext);
        [PreserveSig] int GetMasterVolumeLevel(out float levelDb);
        [PreserveSig] int GetMasterVolumeLevelScalar(out float level);
        [PreserveSig] int SetChannelVolumeLevel(uint channel, float levelDb, ref Guid eventContext);
        [PreserveSig] int SetChannelVolumeLevelScalar(uint channel, float level, ref Guid eventContext);
        [PreserveSig] int GetChannelVolumeLevel(uint channel, out float levelDb);
        [PreserveSig] int GetChannelVolumeLevelScalar(uint channel, out float level);
        [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid eventContext);
        [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
        [PreserveSig] int GetVolumeStepInfo(out uint step, out uint stepCount);
        [PreserveSig] int VolumeStepUp(ref Guid eventContext);
        [PreserveSig] int VolumeStepDown(ref Guid eventContext);
        [PreserveSig] int QueryHardwareSupport(out uint hardwareSupportMask);
        [PreserveSig] int GetVolumeRange(out float minDb, out float maxDb, out float incrementDb);
    }

    private static bool WithEndpoint(Func<IAudioEndpointVolume, bool> action)
    {
        object? enumeratorObject = null;
        IMMDevice? device = null;
        object? endpointObject = null;
        try
        {
            enumeratorObject = new MMDeviceEnumeratorComObject();
            var enumerator = (IMMDeviceEnumerator)enumeratorObject;
            if (enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia, out device) != 0) return false;
            Guid iid = typeof(IAudioEndpointVolume).GUID;
            if (device.Activate(ref iid, CLSCTX_ALL, IntPtr.Zero, out endpointObject) != 0) return false;
            return action((IAudioEndpointVolume)endpointObject);
        }
        catch
        {
            return false;
        }
        finally
        {
            if (endpointObject != null && Marshal.IsComObject(endpointObject)) Marshal.ReleaseComObject(endpointObject);
            if (device != null && Marshal.IsComObject(device)) Marshal.ReleaseComObject(device);
            if (enumeratorObject != null && Marshal.IsComObject(enumeratorObject)) Marshal.ReleaseComObject(enumeratorObject);
        }
    }

    public static bool TryGetVolume(out float volume)
    {
        volume = 0.5f;
        float result = volume;
        bool ok = WithEndpoint(endpoint => endpoint.GetMasterVolumeLevelScalar(out result) == 0);
        volume = Math.Clamp(result, 0f, 1f);
        return ok;
    }

    public static bool TrySetVolume(float volume)
    {
        volume = Math.Clamp(volume, 0f, 1f);
        return WithEndpoint(endpoint => { Guid context = Guid.Empty; return endpoint.SetMasterVolumeLevelScalar(volume, ref context) == 0; });
    }

    public static bool TryGetMute(out bool muted)
    {
        muted = false;
        bool result = false;
        bool ok = WithEndpoint(endpoint => endpoint.GetMute(out result) == 0);
        muted = result;
        return ok;
    }

    public static bool TrySetMute(bool muted)
    {
        return WithEndpoint(endpoint => { Guid context = Guid.Empty; return endpoint.SetMute(muted, ref context) == 0; });
    }

    public static bool TryToggleMute(out bool muted)
    {
        muted = false;
        bool next = false;
        bool ok = WithEndpoint(endpoint =>
        {
            if (endpoint.GetMute(out bool current) != 0) return false;
            next = !current;
            Guid context = Guid.Empty;
            return endpoint.SetMute(next, ref context) == 0;
        });
        muted = next;
        return ok;
    }
}
