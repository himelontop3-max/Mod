using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

namespace VRON.Shell;

/// <summary>
/// Lightweight, on-demand system metrics. The caller should sample only while its
/// monitoring panel is visible; this class does not create a background thread.
/// </summary>
internal static class SystemMetrics
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX buffer);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetSystemTimes(out FILETIME idle, out FILETIME kernel, out FILETIME user);

    private static ulong _lastIdle;
    private static ulong _lastKernel;
    private static ulong _lastUser;
    private static bool _hasCpuSample;

    internal readonly record struct Snapshot(double? CpuPercent, double RamUsedGb, double RamTotalGb,
        double RamAvailableGb, double RamPercent);

    internal static Snapshot Read()
    {
        double? cpu = ReadCpuPercent();
        MEMORYSTATUSEX memory = new() { dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>() };
        if (!GlobalMemoryStatusEx(ref memory) || memory.ullTotalPhys == 0)
            return new Snapshot(cpu, 0, 0, 0, 0);

        const double Gb = 1024d * 1024d * 1024d;
        double total = memory.ullTotalPhys / Gb;
        double available = memory.ullAvailPhys / Gb;
        double used = Math.Max(0, total - available);
        return new Snapshot(cpu, used, total, available, memory.dwMemoryLoad);
    }

    private static double? ReadCpuPercent()
    {
        if (!GetSystemTimes(out FILETIME idleFile, out FILETIME kernelFile, out FILETIME userFile))
            return null;

        ulong idle = ToUInt64(idleFile);
        ulong kernel = ToUInt64(kernelFile);
        ulong user = ToUInt64(userFile);
        if (!_hasCpuSample)
        {
            _lastIdle = idle; _lastKernel = kernel; _lastUser = user;
            _hasCpuSample = true;
            return null;
        }

        ulong idleDelta = idle - _lastIdle;
        ulong kernelDelta = kernel - _lastKernel;
        ulong userDelta = user - _lastUser;
        _lastIdle = idle; _lastKernel = kernel; _lastUser = user;
        ulong total = kernelDelta + userDelta;
        if (total == 0) return 0;
        double busy = total > idleDelta ? total - idleDelta : 0;
        return Math.Clamp(100d * busy / total, 0, 100);
    }

    private static ulong ToUInt64(FILETIME value) =>
        ((ulong)(uint)value.dwHighDateTime << 32) | (ulong)(uint)value.dwLowDateTime;
}
