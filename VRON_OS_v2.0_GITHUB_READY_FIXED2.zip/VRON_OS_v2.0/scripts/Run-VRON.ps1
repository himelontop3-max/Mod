$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$candidates = @(
    (Join-Path $root 'dist\win-x64\VRON.Shell.exe'),
    (Join-Path $root 'app\VRON.Shell\bin\Release\net10.0-windows\VRON.Shell.exe')
)
$exe = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $exe) {
    Write-Host 'VRON.Shell.exe was not found. Run scripts\Build-VRON.ps1 or scripts\Publish-VRON.ps1 first.' -ForegroundColor Yellow
    exit 1
}
Start-Process -FilePath $exe -WorkingDirectory (Split-Path $exe)
