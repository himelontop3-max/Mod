$ErrorActionPreference = 'Stop'
$payload = Join-Path $env:ProgramData 'VRON\Payload'
$appSource = Join-Path $payload 'App'
$scriptSource = Join-Path $payload 'Scripts'
$installRoot = Join-Path $env:ProgramFiles 'VRON'
$exe = Join-Path $appSource 'VRON.Shell.exe'
if (-not (Test-Path $exe)) { throw "VRON app payload not found: $exe" }
New-Item -ItemType Directory -Force -Path $installRoot | Out-Null
Copy-Item -Path (Join-Path $appSource '*') -Destination $installRoot -Recurse -Force
$scriptTarget = Join-Path $installRoot 'Scripts'
New-Item -ItemType Directory -Force -Path $scriptTarget | Out-Null
if (Test-Path $scriptSource) { Copy-Item -Path (Join-Path $scriptSource '*') -Destination $scriptTarget -Recurse -Force }
$startMenu = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::CommonPrograms)) 'VRON OS'
New-Item -ItemType Directory -Force -Path $startMenu | Out-Null
$ws = New-Object -ComObject WScript.Shell
$menuLink = $ws.CreateShortcut((Join-Path $startMenu 'VRON OS.lnk'))
$menuLink.TargetPath = Join-Path $installRoot 'VRON.Shell.exe'
$menuLink.WorkingDirectory = $installRoot
$menuLink.Description = 'Launch the VRON desktop shell'
$menuLink.IconLocation = (Join-Path $installRoot 'VRON.Shell.exe')
$menuLink.Save()
# Keep the desktop completely empty: no VRON shortcut is created there.
# Remove old VRON desktop shortcuts from prior test builds if present.
$publicDesktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonDesktopDirectory)
Remove-Item -LiteralPath (Join-Path $publicDesktop 'VRON OS.lnk') -Force -ErrorAction SilentlyContinue
# Remove the old scheduled cleaner; v2.0 cleanup is user-triggered only.
Unregister-ScheduledTask -TaskName 'VRON Safe Temporary File Cleanup' -Confirm:$false -ErrorAction SilentlyContinue

# Start VRON at sign-in for all users. The taskbar/icons stay hidden during normal VRON use.
$commonStartup = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonStartup)
New-Item -ItemType Directory -Force -Path $commonStartup | Out-Null
$startupLink = $ws.CreateShortcut((Join-Path $commonStartup 'VRON OS.lnk'))
$startupLink.TargetPath = Join-Path $installRoot 'VRON.Shell.exe'
$startupLink.WorkingDirectory = $installRoot
$startupLink.Description = 'Start the VRON desktop shell at sign-in'
$startupLink.IconLocation = (Join-Path $installRoot 'VRON.Shell.exe')
$startupLink.Save()

# Keep a local copy of logs and remove only the staging payload, not the installed application.
Remove-Item -LiteralPath $payload -Recurse -Force -ErrorAction SilentlyContinue
