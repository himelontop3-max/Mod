$ErrorActionPreference = 'Continue'
Write-Host "`n=== VRON OS v2.0 PREFLIGHT ===" -ForegroundColor Cyan
if (-not $IsWindows -and $env:OS -ne 'Windows_NT') { Write-Warning 'This WPF shell can only be built and run on Windows.'; exit 1 }
Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, BuildNumber, OSArchitecture | Format-List
Get-CimInstance Win32_Processor | Select-Object -First 1 Name | Format-List
Get-CimInstance Win32_VideoController | Select-Object Name, DriverVersion | Format-Table -AutoSize
$ram = Get-CimInstance Win32_ComputerSystem
Write-Host ("Installed RAM: {0:N1} GB" -f ($ram.TotalPhysicalMemory / 1GB))
if (Get-Command dotnet -ErrorAction SilentlyContinue) {
    Write-Host "`n.NET SDKs:" -ForegroundColor Cyan
    dotnet --list-sdks
    if (-not ((dotnet --list-sdks) -match '^10\.')) { Write-Warning '.NET 10 SDK is missing.' }
} else { Write-Warning '.NET SDK is not installed.' }
Write-Host "`nNo system settings were changed." -ForegroundColor Green
