$ErrorActionPreference = 'Stop'
$task = Get-ScheduledTask -TaskName 'VRON Safe Temporary File Cleanup' -ErrorAction SilentlyContinue
if ($task) {
    Unregister-ScheduledTask -TaskName 'VRON Safe Temporary File Cleanup' -Confirm:$false
    Write-Host 'VRON startup cleanup task removed.' -ForegroundColor Green
} else { Write-Host 'VRON startup cleanup task was not registered.' }
