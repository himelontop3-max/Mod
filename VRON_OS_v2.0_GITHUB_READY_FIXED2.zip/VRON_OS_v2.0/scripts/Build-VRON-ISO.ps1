[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateScript({Test-Path -LiteralPath $_ -PathType Leaf})][string]$WindowsIsoPath,
    [string]$OutputIsoPath = (Join-Path (Split-Path $PSScriptRoot -Parent) 'dist\VRON-OS-v2.0-Windows-Installer.iso'),
    [string]$OscdimgPath
)
$ErrorActionPreference = 'Stop'
if (-not $IsWindows -and $env:OS -ne 'Windows_NT') { throw 'ISO creation must run on Windows because it mounts Windows installation media and uses Microsoft ADK oscdimg.exe.' }
$repo = Split-Path $PSScriptRoot -Parent
$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { throw 'Install the .NET 10 SDK before building VRON.' }
$sdks = & dotnet --list-sdks
if (-not ($sdks -match '^10\.')) { throw 'The .NET 10 SDK is required. Install it from https://dotnet.microsoft.com/download/dotnet/10.0' }
$builder = Join-Path $PSScriptRoot 'Build-VRON-InstallerISO.ps1'
Write-Host '[1/3] Publishing the self-contained VRON Windows x64 app...' -ForegroundColor Cyan
& (Join-Path $PSScriptRoot 'Publish-VRON.ps1')
if ($LASTEXITCODE -ne 0) { throw 'VRON publish step failed.' }
Write-Host '[2/3] Creating bootable Windows installation media...' -ForegroundColor Cyan
& $builder -WindowsIsoPath $WindowsIsoPath -OutputIsoPath $OutputIsoPath -OscdimgPath $OscdimgPath
if (-not (Test-Path -LiteralPath $OutputIsoPath -PathType Leaf)) { throw 'ISO builder did not create the requested ISO.' }
Write-Host '[3/3] Writing SHA-256 checksum...' -ForegroundColor Cyan
$hash = (Get-FileHash -LiteralPath $OutputIsoPath -Algorithm SHA256).Hash.ToLowerInvariant()
Set-Content -LiteralPath ($OutputIsoPath + '.sha256') -Value ("{0}  {1}" -f $hash,[IO.Path]::GetFileName($OutputIsoPath)) -Encoding ASCII
Write-Host "SUCCESS: $OutputIsoPath" -ForegroundColor Green
Write-Host "SHA256: $hash" -ForegroundColor Green
