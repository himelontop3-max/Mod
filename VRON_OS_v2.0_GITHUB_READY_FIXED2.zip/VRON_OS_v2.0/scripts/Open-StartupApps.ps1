Start-Process 'ms-settings:startupapps'
