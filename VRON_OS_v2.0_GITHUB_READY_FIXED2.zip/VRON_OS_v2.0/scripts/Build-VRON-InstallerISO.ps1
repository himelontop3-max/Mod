[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateScript({Test-Path -LiteralPath $_ -PathType Leaf})][string]$WindowsIsoPath,
    [Parameter(Mandatory=$true)][string]$OutputIsoPath,
    [string]$OscdimgPath
)
$ErrorActionPreference = 'Stop'
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$published = Join-Path $repo 'dist\win-x64'
if (-not (Test-Path (Join-Path $published 'VRON.Shell.exe'))) { throw 'Publish first: scripts\Publish-VRON.ps1' }
if (-not $OscdimgPath) {
    $candidates = @(
        "${env:ProgramFiles(x86)}\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe",
        "$env:ProgramFiles\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe"
    )
    $OscdimgPath = $candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}
if (-not $OscdimgPath -or -not (Test-Path -LiteralPath $OscdimgPath)) { throw 'oscdimg.exe not found. Install Microsoft Windows ADK (Deployment Tools) or pass -OscdimgPath.' }
$WindowsIsoPath = [IO.Path]::GetFullPath($WindowsIsoPath)
$OutputIsoPath = [IO.Path]::GetFullPath($OutputIsoPath)
New-Item -ItemType Directory -Force -Path (Split-Path $OutputIsoPath) | Out-Null
if (Test-Path -LiteralPath $OutputIsoPath) { Remove-Item -LiteralPath $OutputIsoPath -Force }
$work = Join-Path ([IO.Path]::GetTempPath()) ('VRON-ISO-' + [guid]::NewGuid().ToString('N'))
$media = Join-Path $work 'media'
New-Item -ItemType Directory -Force -Path $media | Out-Null
$mounted = $null
try {
    $mounted = Mount-DiskImage -ImagePath $WindowsIsoPath -PassThru
    $volume = Get-Volume -DiskImage $mounted | Where-Object DriveLetter | Select-Object -First 1
    if (-not $volume) { throw 'Could not find a drive letter for the mounted Windows ISO.' }
    $sourceRoot = "$($volume.DriveLetter):\"
    Copy-Item -Path (Join-Path $sourceRoot '*') -Destination $media -Recurse -Force
    $bootBios = Join-Path $media 'boot\etfsboot.com'
    $bootUefi = Join-Path $media 'efi\microsoft\boot\efisys.bin'
    if (-not (Test-Path $bootBios) -or -not (Test-Path $bootUefi)) { throw 'Source ISO does not contain expected BIOS and UEFI boot files. Use a standard x64 Windows installation ISO.' }
    if (-not (Test-Path (Join-Path $media 'sources\install.wim')) -and -not (Test-Path (Join-Path $media 'sources\install.esd'))) { throw 'Source ISO is missing sources\install.wim or install.esd.' }
} finally {
    if ($mounted) { Dismount-DiskImage -ImagePath $WindowsIsoPath -ErrorAction SilentlyContinue }
}
$oem = Join-Path $media 'sources\$OEM$'
$appPayload = Join-Path $oem '$1\ProgramData\VRON\Payload\App'
$scriptPayload = Join-Path $oem '$1\ProgramData\VRON\Payload\Scripts'
$setupScripts = Join-Path $oem '$$\Setup\Scripts'
New-Item -ItemType Directory -Force -Path $appPayload,$scriptPayload,$setupScripts | Out-Null
Copy-Item -Path (Join-Path $published '*') -Destination $appPayload -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot '*') -Destination $scriptPayload -Recurse -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Install-VRON-From-Setup.ps1') -Destination (Join-Path $setupScripts 'Install-VRON-From-Setup.ps1') -Force
@'
@echo off
setlocal
set "LOG=%ProgramData%\VRON\Logs\setup-complete.log"
if not exist "%ProgramData%\VRON\Logs" mkdir "%ProgramData%\VRON\Logs"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-VRON-From-Setup.ps1" >> "%LOG%" 2>&1
exit /b 0
'@ | Set-Content -LiteralPath (Join-Path $setupScripts 'SetupComplete.cmd') -Encoding ASCII
$bootData = '-bootdata:2#p0,e,b"{0}"#pEF,e,b"{1}"' -f $bootBios,$bootUefi
$label = 'VRON_WIN_SETUP'
& $OscdimgPath -m -o -u2 -udfver102 $bootData "-l$label" $media $OutputIsoPath
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $OutputIsoPath)) { throw "oscdimg failed with exit code $LASTEXITCODE" }
Write-Host "Created bootable Windows installer ISO with VRON payload: $OutputIsoPath" -ForegroundColor Green
Write-Host 'This ISO installs the Windows edition contained in the source ISO; VRON is an added desktop shell, not a separate Windows kernel or edition.' -ForegroundColor Yellow
Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
