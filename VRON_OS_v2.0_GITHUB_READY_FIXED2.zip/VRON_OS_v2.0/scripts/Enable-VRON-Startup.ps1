$ErrorActionPreference = 'Stop'
$installed = Join-Path $env:ProgramFiles 'VRON\VRON.Shell.exe'
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$built = Join-Path $repo 'dist\win-x64\VRON.Shell.exe'
$exe = if (Test-Path $installed) { $installed } elseif (Test-Path $built) { $built } else { throw 'VRON.Shell.exe not found. Install VRON or publish it first.' }
$startup = [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
$linkPath = Join-Path $startup 'VRON OS.lnk'
$ws = New-Object -ComObject WScript.Shell
$link = $ws.CreateShortcut($linkPath)
$link.TargetPath = $exe
$link.WorkingDirectory = Split-Path $exe
$link.Description = 'VRON OS minimal launcher and dock'
$link.Save()
Write-Host 'VRON will launch at sign-in for this user.' -ForegroundColor Green
