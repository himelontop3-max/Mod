# Emergency recovery utility: show the Windows taskbar and desktop icons again.
# Run this if VRON is closed unexpectedly and Windows chrome did not restore.
$source = @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class VronDesktopRecovery {
    public delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc callback, IntPtr data);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindowEx(IntPtr parent, IntPtr after, string className, string windowName);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hwnd, int command);
    public static void Restore() {
        EnumWindows((hwnd, data) => {
            var cls = new StringBuilder(128);
            GetClassName(hwnd, cls, cls.Capacity);
            if (cls.ToString() == "Shell_TrayWnd" || cls.ToString() == "Shell_SecondaryTrayWnd") ShowWindow(hwnd, 5);
            IntPtr view = FindWindowEx(hwnd, IntPtr.Zero, "SHELLDLL_DefView", null);
            if (view != IntPtr.Zero) {
                IntPtr list = FindWindowEx(view, IntPtr.Zero, "SysListView32", "FolderView");
                if (list != IntPtr.Zero) ShowWindow(list, 5);
            }
            return true;
        }, IntPtr.Zero);
    }
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr hwnd, StringBuilder text, int max);
}
'@
Add-Type -TypeDefinition $source -ErrorAction Stop
[VronDesktopRecovery]::Restore()
# Restore any notification state changed by VRON before an unexpected exit.
$settingsPath = Join-Path $env:APPDATA 'VRON\settings.json'
if (Test-Path $settingsPath) {
    try {
        $settings = Get-Content $settingsPath -Raw | ConvertFrom-Json
        if ($settings.DoNotDisturbEnabled) {
            $previous = 1
            if ($null -ne $settings.PreviousToastSetting) { $previous = [int]$settings.PreviousToastSetting }
            $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings'
            New-Item -Path $key -Force | Out-Null
            New-ItemProperty -Path $key -Name 'NOC_GLOBAL_SETTING_TOASTS_ENABLED' -Value $previous -PropertyType DWord -Force | Out-Null
            $settings.DoNotDisturbEnabled = $false
            $settings.PreviousToastSetting = $null
            $settings | ConvertTo-Json -Depth 20 | Set-Content -Path $settingsPath -Encoding UTF8
        }
    } catch { Write-Warning "Notification preference restore skipped: $($_.Exception.Message)" }
}
Write-Host 'Desktop visibility and any VRON notification change have been restored.' -ForegroundColor Green
