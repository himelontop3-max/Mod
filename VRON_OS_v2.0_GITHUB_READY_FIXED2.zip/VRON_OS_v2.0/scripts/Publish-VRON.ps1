$ErrorActionPreference = 'Stop'
$project = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\app\VRON.Shell\VRON.Shell.csproj'))
$out = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\dist\win-x64'))
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'The .NET 10 SDK is required. Install it from https://dotnet.microsoft.com/download/dotnet/10.0'
}
$sdks = & dotnet --list-sdks
if (-not ($sdks -match '^10\.')) { throw 'The .NET 10 SDK was not found.' }
New-Item -ItemType Directory -Force -Path $out | Out-Null
& dotnet publish $project --configuration Release --runtime win-x64 --self-contained true `
    -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true `
    --output $out
if ($LASTEXITCODE -ne 0) { throw 'VRON publish failed.' }
Write-Host "Published self-contained Windows x64 app to: $out" -ForegroundColor Green
Write-Host 'The .NET desktop runtime is bundled. For bootable Windows installer media, use scripts\Build-VRON-InstallerISO.ps1 with a licensed Windows x64 ISO and Microsoft ADK oscdimg.exe.' -ForegroundColor Yellow
