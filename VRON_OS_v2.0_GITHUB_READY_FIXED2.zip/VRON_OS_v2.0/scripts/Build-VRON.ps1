$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot '..\app\VRON.Shell\VRON.Shell.csproj'
$project = [IO.Path]::GetFullPath($project)
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'The .NET 10 SDK is required. Install it from https://dotnet.microsoft.com/download/dotnet/10.0'
}
$sdks = & dotnet --list-sdks
if (-not ($sdks -match '^10\.')) {
    throw 'The .NET 10 SDK was not found. Install .NET SDK 10.x, then rerun this script.'
}
& dotnet build $project --configuration Release
if ($LASTEXITCODE -ne 0) { throw 'VRON build failed. Review the compiler output above.' }
Write-Host 'Build complete. Run scripts\Run-VRON.ps1 to launch the shell.' -ForegroundColor Green
