[CmdletBinding()]
param()
$os = Get-CimInstance Win32_OperatingSystem
$totalMb = [math]::Round($os.TotalVisibleMemorySize / 1024, 0)
$freeMb = [math]::Round($os.FreePhysicalMemory / 1024, 0)
$vron = Get-Process -Name 'VRON.Shell' -ErrorAction SilentlyContinue | Select-Object -First 1
$workingSetMb = if ($vron) { [math]::Round($vron.WorkingSet64 / 1MB, 1) } else { $null }
[pscustomobject]@{
    Computer = $env:COMPUTERNAME
    OS = $os.Caption
    TotalRAM_MB = $totalMb
    AvailableRAM_MB = $freeMb
    VRON_Running = [bool]$vron
    VRON_WorkingSet_MB = $workingSetMb
    SampleTime = Get-Date
} | Format-List
Write-Host 'Tip: compare readings after the system has settled for a few minutes. A single sample is not a benchmark.' -ForegroundColor Yellow
