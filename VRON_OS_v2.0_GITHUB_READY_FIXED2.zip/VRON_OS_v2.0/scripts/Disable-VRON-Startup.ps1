$ErrorActionPreference = 'Stop'
$userStartup = [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
$userLink = Join-Path $userStartup 'VRON OS.lnk'
if (Test-Path -LiteralPath $userLink) {
    Remove-Item -LiteralPath $userLink -Force
    Write-Host 'Per-user VRON startup link removed.' -ForegroundColor Green
}
$commonStartup = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonStartup)
$commonLink = Join-Path $commonStartup 'VRON OS.lnk'
if (Test-Path -LiteralPath $commonLink) {
    try {
        Remove-Item -LiteralPath $commonLink -Force
        Write-Host 'All-users VRON startup link removed.' -ForegroundColor Green
    } catch {
        Write-Warning 'The all-users startup link could not be removed. Run this script as Administrator to disable VRON for every account.'
    }
}
