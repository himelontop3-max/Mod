$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Warning 'Run PowerShell as Administrator to request a restore point.'
    exit 1
}
if ((Read-Host 'A restore point is not a replacement for a full backup. Type YES to continue') -cne 'YES') { exit }
Checkpoint-Computer -Description ("VRON Before Changes {0}" -f (Get-Date -Format 'yyyy-MM-dd_HHmm')) -RestorePointType MODIFY_SETTINGS
Write-Host 'Restore point request completed.' -ForegroundColor Green
