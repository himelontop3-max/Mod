$ErrorActionPreference = 'Continue'
Write-Host "`n=== VRON READ-ONLY HEALTH AUDIT ===" -ForegroundColor Cyan
Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, BuildNumber, OSArchitecture,
    @{Name='RAM_Total_GB';Expression={[math]::Round($_.TotalVisibleMemorySize / 1MB, 2)}},
    @{Name='RAM_Free_GB';Expression={[math]::Round($_.FreePhysicalMemory / 1MB, 2)}} | Format-List
Write-Host "`n--- CPU ---"
Get-CimInstance Win32_Processor | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors | Format-List
Write-Host "`n--- Display adapters ---"
Get-CimInstance Win32_VideoController | Select-Object Name, DriverVersion, VideoModeDescription | Format-Table -AutoSize
Write-Host "`n--- Startup Run entries (read-only) ---"
$paths = @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run')
foreach ($path in $paths) { if (Test-Path $path) { Write-Host "`n$path"; Get-ItemProperty $path | Select-Object -ExcludeProperty PS* | Format-List } }
Write-Host "`n--- Power plans ---"
powercfg /list
Write-Host "`nAudit completed. This script did not change settings." -ForegroundColor Green
