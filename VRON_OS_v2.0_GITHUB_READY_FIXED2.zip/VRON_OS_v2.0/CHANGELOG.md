# VRON OS v2.0

## Added
- Seconds in the VRON clock (12-hour time with AM/PM).
- Control Center media controls: Previous, Play/Pause and Next via standard Windows media keys.
- Refresh VRON tile reloads the app catalogue, dock and drawer.
- Updated version metadata and GitHub Actions artifact/release naming to v2.0.

## Preserved
- Windows 10 IoT Enterprise LTSC 2021 x64 target.
- Midnight-blue / pumpkin-orange theme, transparent bottom dock, app drawer, editable app shortcuts, hidden native taskbar/desktop icons while active, DND, screenshot/record shortcuts, safe optimizer and recovery utilities.

## Notes
- Media-key behavior depends on the active player's Windows media-session support.
- Full arbitrary-window left-side taskbar/window manager and a complete native Windows Search replacement are not implemented in this source revision.
- The WPF app still requires a Windows GitHub Actions build and real-device testing. No bootable ISO or Windows activation bypass is included.
