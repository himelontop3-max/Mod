# VRON OS v2.0 — Midnight Blue / Pumpkin Orange

**VRON is a custom Windows desktop-shell experience**, not a separate kernel or independently licensed Windows distribution. Its intended base is **Windows 10 IoT Enterprise LTSC 2021 x64 (21H2)**. The desktop surface is VRON-branded; the native taskbar and desktop icons stay hidden while VRON is running. The underlying Explorer and Windows components remain available for compatibility and recovery.

VRON itself has no separate product key or activation step. The underlying Windows installation still has to comply with the licence for the source media. This project does not activate Windows or alter licensing.

## Visual direction

- Midnight navy surfaces, pumpkin-orange accents, subtle native DWM acrylic on panels only when opened.
- A transparent, borderless, icon-only dock at the bottom. It scrolls horizontally when many apps are pinned.
- A right-side app drawer opened by tapping the Windows key or selecting All Apps. The drawer has search, clock/date, macOS-inspired close/minimize/maximize dots and a consistent VRON Fluent-inspired icon pack.
- Bundled custom app PNG icons use the VRON palette. The UI prefers Segoe Fluent Icons when installed and falls back to the compatible Segoe MDL2 font for text-only/system controls.
- No desktop icons, no native taskbar, no Windows logo or branding in the VRON desktop panels. System utilities opened by a shortcut may still display their own native UI.
- No animations or transition effects. Blur is native DWM composition, not a WPF software blur effect.

## Included app shortcuts

| Destination | VRON name |
|---|---|
| This PC | Inventory |
| Recycle Bin | Hell |
| Paint | Canvas |
| Command Prompt | CMD |
| Control Panel | Panel |
| PowerShell | PowerShell |
| Camera | Cam |
| Microsoft Store | Microsoft Store |
| Notepad | Notes |
| Photos | Gallery |
| Calendar | Timeline |
| Clock | Time |
| Default browser | Browser (removable shortcut only) |

The app drawer starts with only your requested built-ins plus the removable Browser shortcut. Optimizer and system-management tools live inside Control Center rather than adding more app tiles. Right-click any app tile to rename it, pin/unpin it, or remove it from VRON. Use the All Apps dock icon's context menu to restore hidden built-ins and original names. Add app imports a chosen `.exe`; custom apps can also be renamed and deleted. Removing a tile does not uninstall the underlying system component. Use Installed app management in Optimizer for normal per-app uninstall choices.

No browser is bundled. Browser opens a start page through the user's registered default browser; remove the shortcut or add any browser you choose. Camera, Photos, Calendar, Clock and Store shortcuts only work if those apps/protocol handlers are present in the selected LTSC image. VRON does not download replacements silently.

## v2.0 additions

- Clock shows seconds (12-hour clock with AM/PM) in open VRON panels, updated once per second only while the drawer or Control Center is open.
- Control Center includes a Refresh VRON action to reload the app catalogue and redraw the dock/drawer without restarting the shell.
- Media controls send the standard Windows Previous / Play-Pause / Next media keys to the active background media session. Actual response depends on the media player and its Windows media-session support.
- Existing dock and drawer remain intentionally lightweight: no animated transitions, no embedded browser, and no always-running visualizer.

The Windows Start menu / taskbar is hidden while VRON is active, and VRON's launcher remains a compact app drawer. A native Windows search flyout or fully replacement taskbar is not claimed by this build. External application windows keep their own normal minimize/maximize/close controls; VRON does not yet provide a complete window-manager-style left running-app shelf for arbitrary third-party windows.

## Control Center

Open it from the dock, the thin orange right-edge handle (click or pull it left), or `Ctrl+Alt+Shift+C`. It includes: 

- Wi-Fi, Airplane mode, Hotspot, Eye comfort, Bluetooth, Dark mode and Settings shortcuts. Radio controls open the relevant system page; they do not run background commands to force adapter states.
- **Do Not Disturb** toggle for the current user. It saves the prior toast-notification value, disables toast notifications while VRON is active, and restores that value on normal exit. The emergency recovery script also attempts restoration after a crash.
- Screenshot via `Win+Shift+S`.
- Screen recording via the native `Win+Alt+R` Game Bar shortcut when the capture overlay exists. Some LTSC images omit Game Bar; add your preferred recorder as a custom app if the shortcut is unavailable.
- Volume and mute using the default Windows Core Audio endpoint; display brightness using monitor DDC/CI where supported; bass/treble link to the device's sound controls because support is driver-specific.
- Download/upload speed, sampled once per second only while Control Center is visible.
- Cleaner and Optimizer shortcuts.

## Optimizer and performance policy

Optimizer shows CPU and physical-memory use. Its metrics timer runs only while the Optimizer window is open and stops when hidden or closed. Available actions include Startup Apps, installed-app management, background-app permissions, power settings, Disk Cleanup, Task Manager, restore-point settings, SFC verification, DISM/SFC repair and the safe Temp cleaner. Repair commands ask first and require the normal administrator approval prompt.

The cleaner only considers files older than 14 days in the current user's top-level Temp folder. It skips directories, reparse points and files that are in use. It does not delete browser profiles, shader caches, Prefetch, Windows Update files or the system pagefile.

**No fake RAM cleaner:** Windows uses unused RAM as a cache and can release it when apps need memory. Purging standby memory or repeatedly trimming all processes can cause disk reloads and make an 8 GB PC slower. VRON reports RAM availability and opens Task Manager so you can close apps you recognise. It does not flush the system cache.

**No blind service killer:** VRON does not mass-disable services, Defender, Firewall, Windows Update, drivers, recovery or the pagefile; it does not edit BCD/bootloader settings. On LTSC, the safe way to reduce startup load is to review Startup Apps and uninstall optional apps you recognise. Disabling essential services can break audio, networking, USB, updates, logon or the shell. There is no magic CPU command that safely makes an older CPU faster.

Visual choices for the target i3 / Intel HD / 8 GB system: no animations, no always-on network polling, no background cleanup task, no embedded browser, cached small PNG icons, native blur only on opened panels, and metrics only while Optimizer is visible. Real RAM/CPU/GPU load still needs testing on the actual PC.

## Shortcuts and recovery

- Tap **Win** to open App Drawer. If the low-level keyboard hook cannot install, use **Win+Space**.
- `Ctrl+Alt+Shift+C` opens Control Center.
- `Ctrl+Alt+Shift+Q` exits VRON.
- Exiting normally restores the taskbar and desktop-icon visibility VRON found at startup. This is an emergency/recovery path, not part of the active VRON desktop. If VRON crashes before cleanup, run `RESTORE-WINDOWS-DESKTOP.cmd` from the package or `scripts\Restore-Windows-Desktop.ps1`. It restores taskbar/desktop visibility and attempts to restore the previous DND setting.

The taskbar and desktop icons are hidden throughout normal VRON use after the shell starts at sign-in; a lightweight five-second check re-hides a taskbar if the standard shell recreates it. A brief native sign-in/startup flash can still occur because this safe build keeps the standard shell available underneath; eliminating that completely would require a riskier shell replacement, which is not enabled by default. Explorer is not killed or replaced in v2.0, because it provides shell integration and helps preserve a reliable recovery route. Native Settings, Task Manager, file dialogs and some app windows can still display their own native interface. Fully replacing the Windows logon shell would be a separate, higher-risk phase and is not claimed here.

## Build the Windows x64 app with GitHub Actions

1. Extract this ZIP.
2. Upload the **contents** of the `VRON_OS_v2.0` folder to the root of your GitHub repository, including `.github`. Do not upload only the ZIP.
3. Open **Actions → Build VRON OS v2.0 → Run workflow** (or push to `main`).
4. Download artifact `VRON-OS-v2.0-Windows-x64`. It contains the full source package and published output.
5. Extract and run `VRON.Shell.exe` on Windows to test. Keep the recovery script close by.

The workflow uses a Windows GitHub-hosted runner and .NET 10 to publish a self-contained Windows x64 WPF shell. This source package has not been compiled on this Linux packaging host. A successful workflow is still not a substitute for a real run test on your device.

## Bootable installer ISO

The optional ISO workflow requires a **self-hosted Windows x64 runner** with .NET 10, Microsoft Windows ADK Deployment Tools (`oscdimg.exe`) and your own licensed Windows 10 IoT Enterprise LTSC 2021 x64 installation ISO accessible to that runner. The ISO builder only adds the VRON payload after Setup; it does not convert another edition to IoT LTSC, remove packages, include a licence, activate Windows or bypass security requirements. Check the source ISO edition before installing. No ISO is included in this package.

Local Windows build: run `BUILD-ISO-ON-WINDOWS.cmd`, or run `scripts\Build-VRON-ISO.ps1` with `-WindowsIsoPath` and `-OutputIsoPath`. The ISO is not ready until built from your media and tested.

## Verification status

- Project metadata, icon assets, workflow files, JSON config, XML and archive structure are checked during packaging.
- WPF compilation and runtime behaviour require the Windows GitHub Actions runner and a real Windows test machine.
- CPU/RAM telemetry, DND registry behaviour, capture hotkeys, acrylic, monitor brightness, audio controls and taskbar restoration still require on-device testing.
- The ISO needs your licensed source media plus ADK; it is not part of this ZIP.
