# Official references

- Windows ADK download and version guidance: https://learn.microsoft.com/en-us/windows-hardware/get-started/adk-install
- Windows 10 end-of-support and Consumer ESU: https://www.microsoft.com/en-us/windows/extended-security-updates
- Windows 11 hardware requirements: https://learn.microsoft.com/en-us/windows/whats-new/windows-11-requirements
- Windows 11 supported Intel processors: https://learn.microsoft.com/en-us/windows-hardware/design/minimum/supported/windows-11-supported-intel-processors
- Windows file-cache and memory-manager behavior: https://learn.microsoft.com/en-us/windows-server/administration/performance-tuning/subsystem/cache-memory-management
- Windows page file and commit limit: https://learn.microsoft.com/en-us/troubleshoot/windows-client/performance/introduction-to-the-page-file
- Windows service optimization guidance: https://learn.microsoft.com/en-us/windows/iot/iot-enterprise/optimize/services
