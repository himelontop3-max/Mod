# VRON installer ISO boundary

VRON is a Windows desktop-shell experience and installer customisation, not an independent kernel or a replacement operating system. The ISO builder takes original Windows installation media supplied by the user, adds the VRON SetupComplete payload, and rebuilds bootable media using Microsoft ADK `oscdimg.exe`.

The intended base is **Windows 10 IoT Enterprise LTSC 2021 x64 (21H2)**. The source ISO must already contain that edition. The script does not change the edition, remove servicing components, inject unsigned drivers, include a Windows licence, bypass activation/licensing, modify the bootloader, or bypass hardware/security requirements. VRON itself has no separate product key or activation process; the underlying Windows installation remains subject to its own licence terms.

The source ISO is not included. Obtain installation media through an authorised channel for your licence. Microsoft Windows ADK Deployment Tools provides `oscdimg.exe`. The resulting ISO installs the edition present in the source media and adds VRON after Setup; it is not a preactivated or licence-modified image.
