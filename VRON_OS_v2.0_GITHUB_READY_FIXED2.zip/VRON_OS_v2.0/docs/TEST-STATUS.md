# VRON OS v2.0 — Test status

## Packaging checks

The source package includes the .NET 10 WPF app, icon PNGs, source scripts and updated GitHub Actions workflows. Static JSON/XML/YAML and archive checks are run during packaging.

## Not yet tested on Windows

- `dotnet publish` and WPF runtime launch.
- Windows-key hook pass-through, keyboard shortcuts and emergency exit.
- App drawer, icon loading, rename/remove/restore operations and custom app launch.
- DWM acrylic appearance, dock scrolling and Intel HD 4400 frame-time impact.
- Taskbar hiding/restoration across Explorer restarts, multiple monitors, sleep/resume and crashes.
- Screenshot and Game Bar recorder hotkeys; the recording overlay may be absent from LTSC.
- DND registry value effect and previous-value recovery.
- CPU/RAM metrics, storage cleaner, SFC/DISM command launch, audio volume and DDC/CI brightness.
- Startup shortcut installation, no-desktop-shortcut behavior, and ISO installation.
- Idle CPU/RAM/GPU use and boot time on the target PC.

## Acceptance checklist

1. Run the GitHub Actions Windows build and confirm it completes.
2. Extract `VRON.Shell.exe` and its `Assets\Icons` folder; run VRON manually before enabling auto-start.
3. Test app launch, rename, hide, restore, pin/unpin and custom shortcut deletion.
4. Test screenshot/recording availability, DND on/off and the recovery script.
5. Test Win+E, Win+R, Win+I, Alt+Tab, display changes, sleep/resume and the panic-exit hotkey.
6. Verify no desktop icons or taskbar show while VRON is active and normal exit restores the previous state.
7. Test on a VM before using an ISO on the physical PC.
8. Measure CPU/RAM usage and startup behavior; do not assume a performance gain without measurements.
