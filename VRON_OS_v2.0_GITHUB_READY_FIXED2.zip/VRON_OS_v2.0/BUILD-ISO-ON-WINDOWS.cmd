@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo   VRON OS v2.0 - Windows Installer ISO Builder
echo ============================================================
echo.
set /p WINDOWS_ISO=Enter full path to your licensed Windows 10 IoT Enterprise LTSC 2021 x64 ISO: 
if not exist "%WINDOWS_ISO%" (
  echo ERROR: ISO file not found.
  pause
  exit /b 1
)
set /p OUTPUT_ISO=Output ISO path [dist\VRON-OS-v2.0-Windows-Installer.iso]: 
if "%OUTPUT_ISO%"=="" set "OUTPUT_ISO=dist\VRON-OS-v2.0-Windows-Installer.iso"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "scripts\Build-VRON-ISO.ps1" -WindowsIsoPath "%WINDOWS_ISO%" -OutputIsoPath "%OUTPUT_ISO%"
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Review the error above and the README prerequisites.
  pause
  exit /b 1
)
echo.
echo ISO build completed. The checksum is beside the ISO.
pause
